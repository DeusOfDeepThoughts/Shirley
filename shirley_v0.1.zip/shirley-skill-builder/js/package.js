(function () {
  'use strict';

  function crc32(bytes) {
    let crc = -1;
    for (let i = 0; i < bytes.length; i += 1) crc = (crc >>> 8) ^ crcTable[(crc ^ bytes[i]) & 0xff];
    return (crc ^ -1) >>> 0;
  }

  const crcTable = (() => {
    const table = new Uint32Array(256);
    for (let n = 0; n < 256; n += 1) {
      let c = n;
      for (let k = 0; k < 8; k += 1) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      table[n] = c >>> 0;
    }
    return table;
  })();

  function dosTime(date) { return ((date.getHours() & 0x1f) << 11) | ((date.getMinutes() & 0x3f) << 5) | ((Math.floor(date.getSeconds() / 2)) & 0x1f); }
  function dosDate(date) { return (((date.getFullYear() - 1980) & 0x7f) << 9) | (((date.getMonth() + 1) & 0x0f) << 5) | (date.getDate() & 0x1f); }
  function le16(value) { return new Uint8Array([value & 0xff, (value >>> 8) & 0xff]); }
  function le32(value) { return new Uint8Array([value & 0xff, (value >>> 8) & 0xff, (value >>> 16) & 0xff, (value >>> 24) & 0xff]); }

  function concatBytes(parts) {
    const total = parts.reduce((sum, part) => sum + part.length, 0);
    const out = new Uint8Array(total);
    let offset = 0;
    parts.forEach((part) => { out.set(part, offset); offset += part.length; });
    return out;
  }

  function createZipBlob(entries) {
    const now = new Date();
    const localParts = [];
    const centralParts = [];
    let offset = 0;

    entries.forEach((entry) => {
      const nameBytes = SkillUtils.textToBytes(entry.name);
      const data = entry.data || new Uint8Array(0);
      const checksum = crc32(data);
      const time = dosTime(now);
      const date = dosDate(now);
      const flags = 0x0800;
      const method = 0;
      const externalAttrs = entry.name.endsWith('/') ? 0x10 : 0;

      const localHeader = concatBytes([
        le32(0x04034b50), le16(20), le16(flags), le16(method), le16(time), le16(date),
        le32(checksum), le32(data.length), le32(data.length), le16(nameBytes.length), le16(0), nameBytes
      ]);
      localParts.push(localHeader, data);

      const centralHeader = concatBytes([
        le32(0x02014b50), le16(20), le16(20), le16(flags), le16(method), le16(time), le16(date),
        le32(checksum), le32(data.length), le32(data.length), le16(nameBytes.length), le16(0), le16(0),
        le16(0), le16(0), le32(externalAttrs), le32(offset), nameBytes
      ]);
      centralParts.push(centralHeader);
      offset += localHeader.length + data.length;
    });

    const centralStart = offset;
    const central = concatBytes(centralParts);
    const eocd = concatBytes([
      le32(0x06054b50), le16(0), le16(0), le16(entries.length), le16(entries.length), le32(central.length), le32(centralStart), le16(0)
    ]);

    return new Blob([...localParts, central, eocd], { type: 'application/zip' });
  }

  function mdSection(title, content) {
    return `## ${title}\n\n${SkillUtils.safeText(SkillUtils.escapeMd(content))}\n`;
  }

  function makeLinkMarkdown(title, links) {
    const lines = [`# ${title}`, ''];
    if (!links.length) {
      lines.push('无。');
    } else {
      links.forEach((item, index) => lines.push(`${index + 1}. ${item.value}`));
    }
    lines.push('');
    return lines.join('\n');
  }

  function flatZipPath(name, fallback = 'file') {
    const raw = String(name || fallback || 'file').split(/[\\/]/).pop() || fallback || 'file';
    return SkillUtils.sanitizeFileName(raw);
  }


  const DEFAULT_FOCUS_CONTENT = "### 计算机相关论文默认的章节安排（共15章）\n\n| 模块 | 核心关注点 | 精读时要问什么 | 记录建议 |\n| --- | --- | --- | --- |\n| **1. 基本信息** | 论文身份与领域定位 | 题目、作者、机构、年份、会议/期刊是什么？属于哪个方向？ | 记录论文来源、关键词、任务类型、应用场景。 |\n| **2. 问题定义** | 研究对象与目标 | 这篇论文到底想解决什么问题？输入是什么？输出是什么？评价目标是什么？ | 用一句话概括：在什么场景下，为了解决什么任务，优化什么指标。 |\n| **3. 研究动机** | 现有方法的不足 | 作者认为前人方法哪里不够好？是效果差、效率低、泛化差、数据依赖强，还是理论解释不足？ | 区分“真实问题”和“作者为了引出方法而强调的问题”。 |\n| **4. 核心贡献** | 新意与价值 | 作者提出了什么新东西？新模型、新算法、新损失、新数据集、新训练策略，还是新分析视角？ | 不要只抄作者贡献点，要判断每个贡献是否被实验支撑。 |\n| **5. 方法框架** | 技术路线与整体结构 | 方法由哪些模块组成？数据如何流动？关键计算过程是什么？ | 画出模型架构图或流程图，重点标明输入、输出、模块关系。 |\n| **6. 关键公式/算法** | 方法的数学本质 | 核心公式、损失函数、优化目标、算法步骤是什么？每个变量代表什么？ | 逐项解释变量含义，避免只看公式形式不理解作用。 |\n| **7. 数据与任务设置** | 数据来源与实验任务 | 使用了哪些数据集？训练、验证、测试如何划分？任务设定是否合理？ | 关注数据规模、类别分布、标注方式、是否存在数据泄漏。 |\n| **8. 实验设计** | 对比与验证逻辑 | Baseline 是否公平？评价指标是否合适？实验是否能证明作者的主张？ | 重点看：主实验、消融实验、泛化实验、鲁棒性实验。 |\n| **9. 结果分析** | 性能提升是否可信 | 提升有多大？是否稳定？是否只在个别数据集或指标上有效？ | 不只看最高分，还要看方差、统计显著性、失败案例和可视化分析。 |\n| **10. 消融与机制验证** | 哪个部分真正有效 | 去掉某个模块后性能如何变化？每个设计是否都有必要？ | 判断方法是“结构真的有效”，还是“参数量、数据量、训练技巧带来的提升”。 |\n| **11. 复杂度与可复现性** | 实际使用成本 | 参数量、计算量、显存、训练时间、推理速度、硬件要求是多少？代码是否开源？ | 记录代码地址、核心超参数、训练细节、环境依赖。 |\n| **12. 局限性与风险** | 方法边界 | 方法在哪些场景下可能失败？是否依赖特定数据、任务、硬件或假设？ | 主动总结作者承认的局限，以及自己发现的潜在问题。 |\n| **13. 迁移与启发** | 对自己研究的价值 | 这个方法、思想、实验设计能否迁移到我的课题？ | 记录可借鉴的技术点、不可直接迁移的限制、后续改进方向。 |\n| **14. 个性化建议** | 根据当前的文章解读结果，结合用户角色，给出进一步的个性化研究建议、为用户试设计新的idea、并规划详细的工作流。 | 结合原文和材料回答本章问题。 | 根据材料清楚记录。 |\n| **15. 前沿研究** | 针对论文涉及到的研究内容，生成前沿研究分析。 | 结合原文和材料回答本章问题。 | 根据材料清楚记录。 |\n\n### 人与动物共有医学相关论文默认的章节安排（共18章）\n\n| 模块 | 核心关注点 | 精读时要问什么 | 记录建议 |\n| --- | --- | --- | --- |\n| **1. 基本信息** | 论文身份与研究类型 | 题目、作者、机构、年份、期刊是什么？属于临床研究、动物实验、流行病学、诊断研究、机制研究，还是综述？ | 先判断研究类型，因为不同论文的证据强度不同。 |\n| **2. 研究对象** | 人、动物、环境三方 | 研究对象是人、动物、病原体、环境样本，还是多者结合？ | 记录人群特征、动物种属/品系、样本来源、环境场景。 |\n| **3. 研究问题** | 医学问题定义 | 论文想解决什么问题？诊断、治疗、预防、传播、机制、风险因素，还是模型验证？ | 用一句话概括：在什么对象中，研究什么因素，对什么结局产生什么影响。 |\n| **4. 研究背景与意义** | 临床、兽医与公共卫生价值 | 为什么这个问题重要？是否涉及发病率、死亡率、传播风险、动物福利、食品安全、抗菌药耐药或公共卫生风险？ | 区分“作者声称的重要性”和“数据实际支持的重要性”。 |\n| **5. 研究设计** | 证据强度 | 是随机试验、队列研究、病例对照、横断面研究、动物实验、体外实验、监测研究，还是系统综述？ | 判断该设计能否支持因果结论，不要把相关性读成因果性。 |\n| **6. 样本与分组** | 样本可靠性 | 样本量是否足够？纳入/排除标准是否清楚？分组是否合理？是否随机、盲法、设对照？ | 动物研究尤其要记录：种属、品系、年龄、性别、健康状态、饲养条件、随机化、盲法。 |\n| **7. 暴露/干预** | 关键变量定义 | 暴露因素或干预措施是什么？如感染、药物、疫苗、饲养方式、接触史、环境污染、抗生素使用等。 | 记录剂量、途径、频率、持续时间、暴露测量方法。 |\n| **8. 结局指标** | 结果是否有医学意义 | 作者测量了什么结果？死亡率、感染率、病原载量、抗体水平、临床评分、病理变化、传播率等。 | 区分替代指标和真正的临床/公共卫生结局。 |\n| **9. 检测与诊断方法** | 测量可信度 | 使用了什么检测方法？PCR、培养、血清学、测序、影像、病理、问卷或临床诊断标准？ | 关注灵敏度、特异度、金标准、采样时间、样本保存与运输。 |\n| **10. 统计分析** | 结果是否稳健 | 是否报告效应量、置信区间、P 值？是否处理混杂因素、缺失数据、重复测量和群体聚集效应？ | 不只看 P 值，更要看效应大小、置信区间和实际医学意义。 |\n| **11. 偏倚与混杂** | 可信性风险 | 是否存在选择偏倚、检测偏倚、回忆偏倚、实验者偏倚、批次效应或未控制的混杂因素？ | 主动问：结果有没有可能由样本来源、分组不均或检测方法导致？ |\n| **12. 机制解释** | 生物学合理性 | 作者是否解释病原、宿主、免疫、组织病理、跨种传播或药物作用机制？ | 把“实验证据支持的机制”和“作者推测的机制”分开记录。 |\n| **13. 跨种转化价值** | 从动物到人，或从人到动物 | 动物结果能否外推到人？人类研究能否反哺动物医学？种属差异是否被讨论？ | 重点写清楚：能转化什么，不能转化什么，外推条件是什么。 |\n| **14. 伦理与生物安全** | 合规性 | 是否说明伦理审批、知情同意、动物福利、3R 原则、生物安全等级和样本处理规范？ | 对动物实验、病原研究、人兽共患病研究，这是核心内容。 |\n| **15. 结论与局限** | 结论边界 | 作者的结论是否超过数据范围？承认了哪些局限？还有哪些未讨论的问题？ | 将局限分为：设计局限、样本局限、测量局限、统计局限、外推局限。 |\n| **16. 实践价值** | 临床、兽医、公共卫生应用 | 研究能否改变诊断、治疗、预防、监测、饲养管理或政策制定？ | 最后判断：这篇论文对医学实践、科研设计或公共卫生决策有什么价值。 |\n| **17. 个性化建议** | 根据当前的文章解读结果，结合用户角色，给出进一步的个性化研究建议、为用户试设计新的idea、并规划详细的工作流。 | 结合原文和材料回答本章问题。 | 根据材料清楚记录。 |\n| **18. 前沿研究** | 针对论文涉及到的研究内容，生成前沿研究分析。 | 结合原文和材料回答本章问题。 | 根据材料清楚记录。 |";

  const DEFAULT_COMPUTER_FOCUS_TEXT = "计算机相关论文默认的章节安排（共15章）\n\n1. 基本信息\n核心关注点：论文身份与领域定位\n精读时要问：题目、作者、机构、年份、会议/期刊是什么？属于哪个方向？\n记录建议：记录论文来源、关键词、任务类型、应用场景。\n\n2. 问题定义\n核心关注点：研究对象与目标\n精读时要问：这篇论文到底想解决什么问题？输入是什么？输出是什么？评价目标是什么？\n记录建议：用一句话概括：在什么场景下，为了解决什么任务，优化什么指标。\n\n3. 研究动机\n核心关注点：现有方法的不足\n精读时要问：作者认为前人方法哪里不够好？是效果差、效率低、泛化差、数据依赖强，还是理论解释不足？\n记录建议：区分“真实问题”和“作者为了引出方法而强调的问题”。\n\n4. 核心贡献\n核心关注点：新意与价值\n精读时要问：作者提出了什么新东西？新模型、新算法、新损失、新数据集、新训练策略，还是新分析视角？\n记录建议：不要只抄作者贡献点，要判断每个贡献是否被实验支撑。\n\n5. 方法框架\n核心关注点：技术路线与整体结构\n精读时要问：方法由哪些模块组成？数据如何流动？关键计算过程是什么？\n记录建议：画出模型架构图或流程图，重点标明输入、输出、模块关系。\n\n6. 关键公式/算法\n核心关注点：方法的数学本质\n精读时要问：核心公式、损失函数、优化目标、算法步骤是什么？每个变量代表什么？\n记录建议：逐项解释变量含义，避免只看公式形式不理解作用。\n\n7. 数据与任务设置\n核心关注点：数据来源与实验任务\n精读时要问：使用了哪些数据集？训练、验证、测试如何划分？任务设定是否合理？\n记录建议：关注数据规模、类别分布、标注方式、是否存在数据泄漏。\n\n8. 实验设计\n核心关注点：对比与验证逻辑\n精读时要问：Baseline 是否公平？评价指标是否合适？实验是否能证明作者的主张？\n记录建议：重点看：主实验、消融实验、泛化实验、鲁棒性实验。\n\n9. 结果分析\n核心关注点：性能提升是否可信\n精读时要问：提升有多大？是否稳定？是否只在个别数据集或指标上有效？\n记录建议：不只看最高分，还要看方差、统计显著性、失败案例和可视化分析。\n\n10. 消融与机制验证\n核心关注点：哪个部分真正有效\n精读时要问：去掉某个模块后性能如何变化？每个设计是否都有必要？\n记录建议：判断方法是“结构真的有效”，还是“参数量、数据量、训练技巧带来的提升”。\n\n11. 复杂度与可复现性\n核心关注点：实际使用成本\n精读时要问：参数量、计算量、显存、训练时间、推理速度、硬件要求是多少？代码是否开源？\n记录建议：记录代码地址、核心超参数、训练细节、环境依赖。\n\n12. 局限性与风险\n核心关注点：方法边界\n精读时要问：方法在哪些场景下可能失败？是否依赖特定数据、任务、硬件或假设？\n记录建议：主动总结作者承认的局限，以及自己发现的潜在问题。\n\n13. 迁移与启发\n核心关注点：对自己研究的价值\n精读时要问：这个方法、思想、实验设计能否迁移到我的课题？\n记录建议：记录可借鉴的技术点、不可直接迁移的限制、后续改进方向。\n\n14. 个性化建议\n核心关注点：根据当前的文章解读结果，结合用户角色，给出进一步的个性化研究建议、为用户试设计新的idea、并规划详细的工作流。\n\n15. 前沿研究\n核心关注点：针对论文涉及到的研究内容，生成前沿研究分析。";

  const DEFAULT_MEDICAL_FOCUS_TEXT = "人与动物共有医学相关论文默认的章节安排（共18章）\n\n1. 基本信息\n核心关注点：论文身份与研究类型\n精读时要问：题目、作者、机构、年份、期刊是什么？属于临床研究、动物实验、流行病学、诊断研究、机制研究，还是综述？\n记录建议：先判断研究类型，因为不同论文的证据强度不同。\n\n2. 研究对象\n核心关注点：人、动物、环境三方\n精读时要问：研究对象是人、动物、病原体、环境样本，还是多者结合？\n记录建议：记录人群特征、动物种属/品系、样本来源、环境场景。\n\n3. 研究问题\n核心关注点：医学问题定义\n精读时要问：论文想解决什么问题？诊断、治疗、预防、传播、机制、风险因素，还是模型验证？\n记录建议：用一句话概括：在什么对象中，研究什么因素，对什么结局产生什么影响。\n\n4. 研究背景与意义\n核心关注点：临床、兽医与公共卫生价值\n精读时要问：为什么这个问题重要？是否涉及发病率、死亡率、传播风险、动物福利、食品安全、抗菌药耐药或公共卫生风险？\n记录建议：区分“作者声称的重要性”和“数据实际支持的重要性”。\n\n5. 研究设计\n核心关注点：证据强度\n精读时要问：是随机试验、队列研究、病例对照、横断面研究、动物实验、体外实验、监测研究，还是系统综述？\n记录建议：判断该设计能否支持因果结论，不要把相关性读成因果性。\n\n6. 样本与分组\n核心关注点：样本可靠性\n精读时要问：样本量是否足够？纳入/排除标准是否清楚？分组是否合理？是否随机、盲法、设对照？\n记录建议：动物研究尤其要记录：种属、品系、年龄、性别、健康状态、饲养条件、随机化、盲法。\n\n7. 暴露/干预\n核心关注点：关键变量定义\n精读时要问：暴露因素或干预措施是什么？如感染、药物、疫苗、饲养方式、接触史、环境污染、抗生素使用等。\n记录建议：记录剂量、途径、频率、持续时间、暴露测量方法。\n\n8. 结局指标\n核心关注点：结果是否有医学意义\n精读时要问：作者测量了什么结果？死亡率、感染率、病原载量、抗体水平、临床评分、病理变化、传播率等。\n记录建议：区分替代指标和真正的临床/公共卫生结局。\n\n9. 检测与诊断方法\n核心关注点：测量可信度\n精读时要问：使用了什么检测方法？PCR、培养、血清学、测序、影像、病理、问卷或临床诊断标准？\n记录建议：关注灵敏度、特异度、金标准、采样时间、样本保存与运输。\n\n10. 统计分析\n核心关注点：结果是否稳健\n精读时要问：是否报告效应量、置信区间、P 值？是否处理混杂因素、缺失数据、重复测量和群体聚集效应？\n记录建议：不只看 P 值，更要看效应大小、置信区间和实际医学意义。\n\n11. 偏倚与混杂\n核心关注点：可信性风险\n精读时要问：是否存在选择偏倚、检测偏倚、回忆偏倚、实验者偏倚、批次效应或未控制的混杂因素？\n记录建议：主动问：结果有没有可能由样本来源、分组不均或检测方法导致？\n\n12. 机制解释\n核心关注点：生物学合理性\n精读时要问：作者是否解释病原、宿主、免疫、组织病理、跨种传播或药物作用机制？\n记录建议：把“实验证据支持的机制”和“作者推测的机制”分开记录。\n\n13. 跨种转化价值\n核心关注点：从动物到人，或从人到动物\n精读时要问：动物结果能否外推到人？人类研究能否反哺动物医学？种属差异是否被讨论？\n记录建议：重点写清楚：能转化什么，不能转化什么，外推条件是什么。\n\n14. 伦理与生物安全\n核心关注点：合规性\n精读时要问：是否说明伦理审批、知情同意、动物福利、3R 原则、生物安全等级和样本处理规范？\n记录建议：对动物实验、病原研究、人兽共患病研究，这是核心内容。\n\n15. 结论与局限\n核心关注点：结论边界\n精读时要问：作者的结论是否超过数据范围？承认了哪些局限？还有哪些未讨论的问题？\n记录建议：将局限分为：设计局限、样本局限、测量局限、统计局限、外推局限。\n\n16. 实践价值\n核心关注点：临床、兽医、公共卫生应用\n精读时要问：研究能否改变诊断、治疗、预防、监测、饲养管理或政策制定？\n记录建议：最后判断：这篇论文对医学实践、科研设计或公共卫生决策有什么价值。\n\n17. 个性化建议\n核心关注点：根据当前的文章解读结果，结合用户角色，给出进一步的个性化研究建议、为用户试设计新的idea、并规划详细的工作流。\n\n18. 前沿研究\n核心关注点：针对论文涉及到的研究内容，生成前沿研究分析。";

  const DEFAULT_OTHER_DOMAIN_FOCUS_TEXT = "其他领域相关论文默认的章节安排如下（共16章）\n\n1. 基本信息\n核心关注点：论文身份与学科定位\n精读时要问：题目、作者、机构、年份、期刊/会议/出版源是什么？属于哪个学科、方向或问题域？\n记录建议：记录研究领域、关键词、研究对象、研究类型和适用场景。\n\n2. 研究对象与范围\n核心关注点：论文研究的对象、边界与适用范围\n精读时要问：研究对象是什么？研究范围覆盖哪些时间、空间、群体、样本、文本、案例或系统？\n记录建议：写清楚“研究什么”和“不研究什么”。\n\n3. 研究问题\n核心关注点：论文要回答的核心问题\n精读时要问：作者提出了哪些研究问题、假设或目标？这些问题是否清楚、可检验、可讨论？\n记录建议：用 1 到 3 句话概括论文主问题和子问题。\n\n4. 研究背景与意义\n核心关注点：为什么值得研究\n精读时要问：作者如何说明问题的重要性？是理论价值、现实价值、政策价值、工程价值、教育价值，还是社会价值？\n记录建议：区分作者声称的意义和论文材料实际支撑的意义。\n\n5. 文献基础与研究空白\n核心关注点：已有研究与本文位置\n精读时要问：作者如何回顾已有研究？指出了什么不足、争议、缺口或未解决问题？\n记录建议：不要只列文献，要判断本文相对已有工作的具体增量。\n\n6. 理论框架或概念框架\n核心关注点：分析所依赖的理论、概念和分类体系\n精读时要问：论文使用了哪些理论、模型、概念、变量或分析框架？这些概念是否定义清楚？\n记录建议：把核心概念、变量关系和分析逻辑画成简图或表格。\n\n7. 研究设计与方法\n核心关注点：作者如何获得证据\n精读时要问：论文采用定量、定性、混合方法、实验、案例、文本分析、调查、访谈、建模，还是理论论证？\n记录建议：说明方法是否适合研究问题，是否存在明显方法局限。\n\n8. 材料、数据与样本\n核心关注点：证据来源是否可靠\n精读时要问：数据、文本、样本、案例或材料来自哪里？规模多大？选择标准是什么？是否有偏倚？\n记录建议：记录来源、筛选过程、样本特征、代表性和可获得性。\n\n9. 分析过程\n核心关注点：从材料到结论的推理链条\n精读时要问：作者如何编码、统计、比较、建模、解释或归纳？分析步骤是否透明？\n记录建议：把关键步骤按顺序整理，标出可能影响结果的主观判断或参数选择。\n\n10. 主要结果\n核心关注点：论文真正发现了什么\n精读时要问：核心发现、数据结果、案例发现、模式、机制或论证结论是什么？\n记录建议：区分“结果本身”和“作者对结果的解释”。\n\n11. 讨论与解释\n核心关注点：结果意味着什么\n精读时要问：作者如何解释结果？是否回应研究问题？是否与既有研究一致或冲突？\n记录建议：标出解释中由证据直接支持的部分，以及推测性较强的部分。\n\n12. 局限性与不确定性\n核心关注点：结论边界与风险\n精读时要问：作者承认了哪些局限？还有哪些未讨论的偏倚、替代解释或外推风险？\n记录建议：从数据、方法、样本、理论、场景和时间范围分别检查。\n\n13. 贡献与应用价值\n核心关注点：论文的实际增量\n精读时要问：论文对理论、方法、实践、政策、工程或教育有什么贡献？贡献是否被证据支撑？\n记录建议：不要直接照抄贡献声明，要判断贡献是否真实成立。\n\n14. 迁移、启发与后续研究\n核心关注点：这篇论文还能带来什么\n精读时要问：哪些思想、方法、框架或证据可以迁移到其他问题？后续研究可以如何改进？\n记录建议：记录可借鉴之处、不可迁移的限制和可进一步追问的问题。\n\n15. 个性化建议\n核心关注点：根据当前的文章解读结果，结合用户角色，给出进一步的个性化研究建议、为用户试设计新的idea、并规划详细的工作流。\n\n16. 前沿研究\n核心关注点：针对论文涉及到的研究内容，生成前沿研究分析。";

  const REQUIRED_SECTION_ZONES = "每个主要章节必须按照“重点关注”中的章节顺序组织，不得自行改成另一套章节框架。\n\n强制要求：\n1）输出结构必须覆盖“重点关注”中列出的每一章。\n2）每一章都必须包含“严格无幻觉区”和“外部解读区”两个子区。\n3）不能只写严格无幻觉区而省略外部解读区。\n4）不能只写外部解读区而省略严格无幻觉区。\n5）不能脱离“重点关注”中的章节顺序另起一套大纲。\n6）如果某一章原文信息不足，严格无幻觉区写“原文未提供”或“原文未提供足够信息”，外部解读区仍需说明可理解的背景、可能影响、学习提示或待补充问题。\n7）若用户上传了新的重点关注内容，应以用户上传或编辑后的重点关注章节为准。\n\n严格无幻觉区负责回答“原文到底说了什么”，必须给出可定位出处。\n外部解读区负责回答“这件事如何理解、为什么重要、可能有什么启发”，必须明确标注为外部解读。\n\n推荐每章内部排版：\n1）章标题沿用“重点关注”中的章节标题。\n2）先给一个简短小结，说明本章解决什么阅读问题。\n3）再写“严格无幻觉区”，事实与出处分离排版。\n4）再写“外部解读区”，解释、类比、批判、启发和外部材料辅助解读单独成区。\n5）涉及方法、结构、流程、实验结果或公式时，必须主动考虑插入原文图讲解、自绘图、表格或公式块。\n6）重要内容可以用加粗、引用块、编号、表格或简洁图示突出。\n\n注意：\n1）不要把“论文出处”直接挤在解读句子后面。\n2）出处应另起一块，建议使用 Markdown 引用块。\n3）不要为了做颜色或卡片效果而输出大量 HTML 标签。\n4）“重点”“难点”“主要”“风险”等标签不是硬性模板，AI 可以根据内容动态决定是否使用。\n5）事实与解读必须分离，出处也必须独立成块。\n6）不能因为可视化限制而完全取消图、表、公式或流程图；应在安全边界内合理使用。\n\n#### 严格无幻觉区\n\n本区域只写可从原论文或已提供参考文献中核验的信息。\n\n核心要求：\n1）可以用 AI 总结，但必须忠实原意。\n2）不得加入常识推断。\n3）不得补全原文没说的信息。\n4）不得美化、拔高或替作者解释。\n5）如果原文没有提供，直接写“原文未提供”。\n6）严格无幻觉区所有事实、数据、变量含义、实验结论和方法描述，只能来自材料清单中 deep_materials 精读材料类别下的文件，或用户明确提供的可核验材料。\n7）不得用整页截图、大段文字截图或连续页面截图代替原文总结。\n8）可以使用原文中的图、表、公式和流程图，但必须是必要的局部内容，并配套解释与出处。\n\n出处排版要求：\n1）每个关键事实后必须给出可定位出处。\n2）出处必须单独成块，不要直接接在句子后面。\n3）出处块与正文之间至少空一行。\n4）出处块建议使用 Markdown 引用块或“论文出处”小标题。\n5）出处块应拆成多行字段，不要写成一长串文字。\n6）不要使用 HTML 的 div、span、br、style 等标签制作出处卡片。\n7）同一事实如果有多个来源，使用多条出处，不要合并成一团。\n\n推荐出处块格式：\n\n> 论文出处\n> 文件：文件名__d_doc_01.pdf\n> 位置：PDF 第 3 页；§2 Method；第 2 段\n> 对象：Figure 2 / Table 1 / 公式 (4) / 正文段落\n> 定位短句：“adaptive threshold mechanism”\n\n出处内容要求：\n1）出处不能只写“原论文”“论文中”“文中提到”“见 Figure 2”。\n2）出处必须尽量包含：材料路径、PDF 页码或文档页码、章节标题、段落位置、图表/公式编号、定位短句。\n3）如果 PDF 页码和论文印刷页码不同，优先写 PDF 页码；如果能看到印刷页码，可同时写。\n4）如果无法确定页码，必须写清楚可定位的章节标题、段落序号或附近小标题。\n5）如果只是根据图、表、公式、算法框得出结论，必须写明 Figure/Table/Equation/Algorithm 编号和图注、表头或公式附近文字。\n6）如果是根据 References 条目，只能写该条目的元信息，并明确说明正文未提供该文献内容。\n7）如果一句话综合了多处信息，必须列出多个出处；不能只给一个笼统出处。\n8）每条出处至少包含一个原文定位短句。定位短句应是原文中的关键词或短语，长度控制在 5 到 25 个词，方便用户用搜索功能找到原文位置。\n9）如果找不到可定位出处，不要把该内容写进严格无幻觉区。\n\n截图与摘录限制：\n1）不得整页截图。\n2）不得用大段原文文字截图顶替分析。\n3）不得连续粘贴多页截图。\n4）不得大段复制原文正文。\n5）必要时只能使用短摘录或局部图像，并说明为什么需要保留原貌。\n6）如果需要引用原文措辞，只引用最短必要短语，并给出可定位出处。\n\n层次与强调：\n1）严格无幻觉区也要有层次，但不要机械规定哪些内容必须叫“重点”“难点”或“主要”。\n2）AI 应根据内容的重要性动态决定是否加粗、编号、分块或使用简短提示词。\n3）可以把真正重要的句子加粗。\n4）可以使用“重点”“难点”“风险”等提示词，但这不是硬性要求。\n5）没有使用这些提示词也可以，只要重要内容被清楚突出即可。\n6）出处块统一放在相关事实后面，不要与解读混成一段。\n\n原文图处理：\n1）如果原文中出现关键图、表、流程图、公式图或结果图，即使无法直接插入到对应位置，也必须标注其位置并解释其作用。\n2）最好能把原图或必要局部放到文档中对应位置，然后紧接着解释。\n3）如果无法插图，应写清楚“此处应对应原文 Figure/Table/Equation X”，并说明其位置、内容和为什么重要。\n4）不要因为不能直接插图就完全忽略原文图。\n\n输出检查：\n1）严格无幻觉区完成后，逐条检查关键事实是否都有可定位出处。\n2）如果某条结论只有模糊出处，改写为更保守的表达，或标注“原文未提供可定位依据”。\n3）检查是否存在整页截图、大段正文截图或用截图堆篇幅的情况；如果存在，必须删除并改为总结加出处。\n4）检查公式是否使用规范 LaTeX 格式；如果公式格式可能无法渲染，应改为更稳定的写法。\n5）检查是否遗漏了原文中对理解非常关键的图、表、公式或流程图。\n6）不要把外部知识、经验判断、类比解释放入严格无幻觉区。\n\n可视化不得缺席：\n1）如果严格无幻觉区涉及原文 Figure、Table、Algorithm 或 Equation，应在对应位置标注并解释。\n2）如果无法插入原图，也必须给出“原文图表位置”块并解释图中核心信息。\n3）如果原文有实验结果表，应至少整理关键结果为 Markdown 表格。\n4）如果原文有关键公式，应至少转写并解释核心公式。\n5）如果原文描述了流程或结构，应考虑用简洁自绘图整理，但必须注明根据原文描述整理。\n\n#### 外部解读区\n\n1. 本区域用于帮助读者理解，可以包含大白话解释、方法直觉、背景知识、与经典方法的关系、工程实现提示、复现建议、批判性分析、潜在风险和外部知识辅助图示。\n2. 如果材料清单中 external_materials 外部材料类别下存在资料，优先使用该类别下的资料进行解读。\n3. 不得把外部图示、外部类比、外部推测及 external_materials 外部材料类别下的资料内容混入严格无幻觉区。\n\n外部解读的信息来源比例：\n1）如果 AI 环境支持联网检索，外部解读区必须主动进行网络检索，不得只依赖模型训练数据。\n2）当 external_materials 存在且可读取、且 AI 也支持联网检索时，外部解读区的外部依据建议按以下比例组织：\n   - external_materials：约 40% 到 60%；\n   - 网络检索资料：约 30% 到 45%；\n   - 其他知识源或模型自身辅助解释：约 0% 到 20%。\n3）如果 external_materials 信息不足，但 AI 支持联网检索，则网络检索资料应提升到约 50% 到 70%。\n4）如果 AI 不支持联网检索，必须明确说明“当前环境不支持联网检索”，不得伪造网络来源；此时应优先使用 external_materials，并谨慎补充模型辅助解读。\n5）模型自身解释只能作为辅助，不能替代 external_materials 或网络检索资料。\n6）如果某一外部解读判断主要来自模型自身解释，应标注“模型辅助解读，非原文事实”。\n\n网络检索要求：\n1）网络检索应优先选择高质量来源，例如官方文档、教材、综述论文、权威机构页面、开源项目文档、标准规范、数据库说明、学术机构材料。\n2）不要用低质量营销文章、无来源博客、论坛碎片信息替代权威资料。\n3）每个来自网络的关键解释都必须标注引用源。\n4）网络来源出处应包含：网页标题或资料名、发布机构或作者、链接或可检索标识、访问日期、定位短句。\n5）网络资料只能放在外部解读区，不得写进严格无幻觉区。\n\nexternal_materials 出处要求：\n1）引用 external_materials 时，应使用独立出处块，不要把出处接在解读文字后面。\n2）出处块应尽量包含：文件名、材料类别、PDF 页码或章节位置、段落位置、定位短句。\n3）不得把 external_materials 的内容写进严格无幻觉区。\n\n外部解读区的图解要求：\n1）外部解读区也要适当使用图解，不得全是文字。\n2）完整精读报告中，外部解读区通常应至少包含 1 到 2 个“外部解读示意图”。\n3）如果外部解读涉及机制、流程、类比、工程实现、复现路线或知识背景，应优先考虑图解。\n4）外部解读图可以根据 external_materials、网络检索资料和模型辅助解释综合绘制，但必须标注“外部解读示意图”，不得作为原文事实依据。\n5）若图解来自网络图片或外部材料图片，必须标注来源；若是自绘图，必须说明“根据外部资料与辅助解释整理”。\n\n排版要求：\n1）外部解读区必须用清楚标题标出，不得伪装成原文内容。\n2）外部解读区不要和严格无幻觉区挤在一起。\n3）每段解读尽量短。\n4）重要内容可以加粗，也可以使用“理解”“复现”“风险”“启发”等提示词，但这些提示词不是硬性模板。\n5）如果引用外部材料或网络材料，也要单独给出处块，不要把出处接在解读文字后面。\n6）不要使用 HTML 的 div、span、br、style 等标签制作颜色块或卡片。\n7）如果只是经验判断或常识解释，应标注确定性：高、中或低。\n\n推荐出处写法：\n\n> 外部材料出处\n> 文件：文件名__e_doc_01.pdf\n> 类别：external_materials 外部材料\n> 位置：PDF 第 4 页；§2.1；第 1 段\n> 定位短句：“...”\n\n> 网络资料出处\n> 标题：资料标题\n> 来源：机构 / 作者 / 网站\n> 链接或检索标识：...\n> 访问日期：YYYY-MM-DD\n> 定位短句：“...”";

  function rawRuleText(value, fallback = '原文未提供') {
    return SkillUtils.safeText(value, fallback).trim();
  }


  function normalizeFocusContentForOutput(text) {
    const clean = String(text || '').trim();
    const defaultWithOther = `${DEFAULT_FOCUS_CONTENT}\n\n${DEFAULT_OTHER_DOMAIN_FOCUS_TEXT}`.trim();
    if (!clean) return defaultWithOther;

    const oldSingleWrapped = `文本关注点：\n\n1. ${DEFAULT_FOCUS_CONTENT}`.trim();
    if (clean === oldSingleWrapped) return DEFAULT_FOCUS_CONTENT;

    const twoDefaultWrapped = `文本关注点：\n\n1. ${DEFAULT_COMPUTER_FOCUS_TEXT}\n\n2. ${DEFAULT_MEDICAL_FOCUS_TEXT}`.trim();
    if (clean === twoDefaultWrapped) return DEFAULT_FOCUS_CONTENT;

    const threeDefaultWrapped = `文本关注点：\n\n1. ${DEFAULT_COMPUTER_FOCUS_TEXT}\n\n2. ${DEFAULT_MEDICAL_FOCUS_TEXT}\n\n3. ${DEFAULT_OTHER_DOMAIN_FOCUS_TEXT}`.trim();
    if (clean === threeDefaultWrapped) return defaultWithOther;

    return clean;
  }

  function focusContent(formData) {
    return normalizeFocusContentForOutput(rawRuleText(formData.focusText, ''));
  }

  function sectionPrincipleText(formData) {
    const intro = rawRuleText(formData.sectionPrinciple, '');
    const strictZone = rawRuleText(formData.strictNoHallucinationZone, '');
    const externalZone = rawRuleText(formData.externalInterpretationZone, '');
    return [
      intro,
      '#### 严格无幻觉区',
      strictZone,
      '#### 外部解读区',
      externalZone
    ].filter(Boolean).join('\n\n');
  }

  function itemManifest(item) {
    const file = item.file || {};
    const name = file.name || item.fileName || 'focus_file';
    const size = Number(file.size || item.size || 0);
    const lastModified = file.lastModified || item.lastModified || null;
    return {
      path: flatZipPath(item.storedPath, name),
      original_name: name,
      size_bytes: size,
      size_readable: SkillUtils.formatBytes(size),
      mime_type: file.type || item.type || 'unknown',
      last_modified: lastModified ? new Date(lastModified).toISOString() : null
    };
  }

  function buildManifest(formData, filesByCategory) {
    const manifest = {
      package_name: 'Shirley_Task_Package.zip',
      created_at: new Date().toISOString(),
      entrypoint: 'START_HERE.md',
      skill_name: SkillUtils.safeText(formData.skillName),
      focus: SkillUtils.safeText(formData.focusText, '默认设置'),
      materials: {
        deep: { docs: [], images: [], data: [], links: [] },
        external: { docs: [], images: [], data: [], links: [] }
      },
      focus_uploads: []
    };

    ['docs', 'images', 'data'].forEach((category) => {
      (filesByCategory[category] || []).forEach((item) => {
        const scope = item.scope === 'external' ? 'external' : 'deep';
        manifest.materials[scope][category].push(itemManifest(item));
      });
    });

    (filesByCategory.links || []).forEach((item) => {
      const scope = item.scope === 'external' ? 'external' : 'deep';
      manifest.materials[scope].links.push({
        value: item.value,
        title: item.title,
        created_at: item.createdAt || null
      });
    });

    const focusFilesForPackage = filesByCategory.effectiveFocusFiles || filesByCategory.focusFiles || [];
    manifest.focus_uploads = focusFilesForPackage.map(itemManifest);
    return manifest;
  }

  function materialList(manifest) {
    const labels = {
      deep: 'deep_materials 精读材料',
      external: 'external_materials 外部材料',
      docs: 'docs 文档',
      images: 'images 图片',
      data: 'data 数据',
      links: 'links 链接'
    };
    const lines = [];

    ['deep', 'external'].forEach((scope) => {
      lines.push(`## ${labels[scope]}`, '');
      ['docs', 'images', 'data', 'links'].forEach((kind) => {
        const items = manifest.materials[scope][kind] || [];
        lines.push(`### ${labels[kind]}`);
        if (!items.length) {
          lines.push('无。', '');
          return;
        }
        items.forEach((item) => {
          if (kind === 'links') lines.push(`- ${item.value}`);
          else lines.push(`- ${item.path} ｜原文件名：${item.original_name} ｜大小：${item.size_readable}`);
        });
        lines.push('');
      });
    });

    lines.push('## focus_uploads 重点关注附件', '');
    if (!manifest.focus_uploads.length) {
      lines.push('无。', '');
    } else {
      manifest.focus_uploads.forEach((item) => {
        lines.push(`- ${item.path} ｜原文件名：${item.original_name} ｜大小：${item.size_readable}`);
      });
      lines.push('');
    }

    return lines.join('\n');
  }

  function buildStartHere(formData, manifest) {
    return `# START_HERE

这是一个 Shirley 生成的 AI 任务包。请直接通读本文档，并按照本文档要求严格执行。

## 目录结构

本任务包解压后只有同一层级文件，不含 deep_materials/、external_materials/、focus_uploads/ 等子文件夹。

根目录包含以下内容：

- START_HERE.md：主入口，包含全部任务说明、规则、重点关注和材料清单。
- 若干已重命名材料文件：所有上传文件均位于同一层级，并已添加短后缀以避免同名冲突。
- deep_links__d_link_01.md：如存在精读链接，会以该文件保存链接列表。
- external_links__e_link_01.md：如存在外部链接，会以该文件保存链接列表。

说明：

- deep_materials、external_materials、focus_uploads 是材料清单中的分类名，不是 zip 内的文件夹名。
- 判断某个文件属于精读材料、外部材料、图片、链接、数据或文档时，必须以“一、材料清单”为准。
- 文件名中的短后缀仅用于避免 zip 内部重名，不改变原文件的材料类别。

## 执行入口

1. 先阅读本文件。
2. 如果“材料清单”中存在 focus_uploads 重点关注附件，请按清单列出的同层级文件名读取，获取用户要求重点关注的内容。
3. 阅读“材料清单”中 deep_materials 精读材料下的文件和链接。
4. 根据下方规则，决定是否参考 external_materials 外部材料下的文件和链接。
5. 如果无法读取某些文件，请明确说明无法读取的文件和影响。
6. 不准要求用户重新说明入口文件。

# 一、材料清单

${materialList(manifest)}

# 二、执行规则

## 1. 角色设定

### 用户角色

${rawRuleText(formData.userRole)}

### AI 角色

${rawRuleText(formData.aiRole)}

## 2. 低幻觉

### 信息来源

${rawRuleText(formData.infoSources)}

### References 使用限制

${rawRuleText(formData.referencesLimit)}

## 3. 重点关注

${focusContent(formData)}

## 4. 输出要求

### 文档风格与格式

${rawRuleText(formData.docStyleFormat)}

### 章节分区原则

${sectionPrincipleText(formData)}

### 可视化原则

${rawRuleText(formData.visualizationPrinciple)}

### 公式要求

${rawRuleText(formData.formulaRequirements)}

# 四、固定执行流程

1. 确认重点关注和材料清单。
2. 先提取“重点关注”中的章节列表，并将其作为最终报告的大纲。不得自行另起一套章节结构。
3. 最终报告必须逐章覆盖“重点关注”中的每一章，章节顺序应与“重点关注”保持一致。
4. 每一章都必须包含两个子区：
   - 严格无幻觉区
   - 外部解读区
5. 不能只写严格无幻觉区，也不能省略外部解读区；如果某章原文信息不足，严格无幻觉区写“原文未提供”或“原文未提供足够信息”，外部解读区仍需给出学习性解释、背景说明、影响分析或待补充问题。
6. 优先处理“材料清单”中 deep_materials 精读材料下的 docs 文档和 links 链接，用于严格无幻觉区。
7. 外部解读区应优先使用“材料清单”中 external_materials 外部材料下的文件和链接；如果 AI 环境支持联网检索，也必须主动检索网络上的高质量相关资料。
8. 当 external_materials 存在且可读取、且 AI 支持联网检索时，外部解读区的外部依据建议约 40% 到 60% 来自 external_materials，约 30% 到 45% 来自网络检索资料，约 0% 到 20% 来自其他知识源或模型自身辅助解释。
9. 如果 external_materials 信息不足但支持联网检索，网络检索资料应提升到约 50% 到 70%；如果不支持联网检索，必须明确说明，不得伪造网络来源。
10. 引用 external_materials 或网络资料时必须标注出处，且不得将 external_materials、网络资料或外部推测内容混入严格无幻觉区。
11. 明确区分“精读材料事实”和“外部材料/网络资料辅助信息”；注意 deep_materials、external_materials 是材料类别，不是 zip 内文件夹。
12. 可视化必须增强：非必要处不要加图，但通过图示能明显讲清楚的方法结构、流程、机制、实验结果、外部背景和复现路线必须加图。
13. 完整报告应合理包含原文图讲解、Markdown 表格、Mermaid 图、ASCII 图、公式块和外部解读示意图；不能长期只用 ASCII 而不用 Mermaid。
14. 如果生成 Markdown 报告，引用原文图或局部截图讲解时，只要可获得图片，就应在 Markdown 中插入图片，而不是只做文字引用。
15. 检查是否存在缺失、冲突、不可读取或不确定的信息。
16. 严格按照“重点关注”和“输出要求”组织结果。
17. 避免空泛回答、跳过关键步骤、编造内容、忽略限制条件。
18. 输出前进行多轮检查：是否逐章覆盖重点关注、每章是否都有两个子区、外部解读是否使用 external_materials 与网络资料、所有引用是否有出处、自绘图数量是否足够、Mermaid 与 ASCII 是否均衡、Markdown 报告中可插入的原文图是否已插入。

# 五、缺失信息处理

如果缺失信息会严重影响任务完成，请先说明缺失项。

如果缺失信息不会阻止初步完成，请继续完成任务，但必须标注“待补充”或“不确定”。

# 六、开始执行

请根据以上内容直接输出最终结果。
`;
  }

  function addFolderEntries(entries) {
    [
      'deep_materials/',
      'deep_materials/docs/',
      'deep_materials/images/',
      'deep_materials/data/',
      'deep_materials/links/',
      'external_materials/',
      'external_materials/docs/',
      'external_materials/images/',
      'external_materials/data/',
      'external_materials/links/',
      'focus_uploads/'
    ].forEach((name) => entries.push({ name, data: new Uint8Array(0) }));
  }




  const MATERIAL_FILE_DB_NAME_V37 = 'shirley-material-files-db-v1';
  const MATERIAL_FILE_STORE_V37 = 'files';

  function openMaterialFileDBForPackage() {
    return new Promise((resolve, reject) => {
      if (!('indexedDB' in window)) {
        reject(new Error('IndexedDB 不可用'));
        return;
      }
      const request = window.indexedDB.open(MATERIAL_FILE_DB_NAME_V37, 1);
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains(MATERIAL_FILE_STORE_V37)) {
          db.createObjectStore(MATERIAL_FILE_STORE_V37, { keyPath: 'id' });
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error || new Error('IndexedDB 打开失败'));
    });
  }

  async function getMaterialBlobFromDB(id) {
    if (!id) return null;
    try {
      const db = await openMaterialFileDBForPackage();
      const record = await new Promise((resolve, reject) => {
        const tx = db.transaction(MATERIAL_FILE_STORE_V37, 'readonly');
        const req = tx.objectStore(MATERIAL_FILE_STORE_V37).get(id);
        req.onsuccess = () => resolve(req.result || null);
        req.onerror = () => reject(req.error || new Error('IndexedDB 读取失败'));
      });
      db.close();
      return record && record.blob ? record.blob : null;
    } catch (_) {
      return null;
    }
  }

  async function materialFileToBytes(item) {
    if (item.file) return SkillUtils.fileToBytes(item.file);
    const blob = await getMaterialBlobFromDB(item.id);
    if (blob) {
      const buffer = await blob.arrayBuffer();
      return new Uint8Array(buffer);
    }
    return new Uint8Array(0);
  }

  const FOCUS_FILE_DB_NAME_V34 = 'shirley-focus-files-db-v1';
  const FOCUS_FILE_STORE_V34 = 'files';

  function openFocusFileDBForPackage() {
    return new Promise((resolve, reject) => {
      if (!('indexedDB' in window)) {
        reject(new Error('IndexedDB 不可用'));
        return;
      }
      const request = window.indexedDB.open(FOCUS_FILE_DB_NAME_V34, 1);
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains(FOCUS_FILE_STORE_V34)) {
          db.createObjectStore(FOCUS_FILE_STORE_V34, { keyPath: 'id' });
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error || new Error('IndexedDB 打开失败'));
    });
  }

  async function getFocusBlobFromDB(id) {
    if (!id) return null;
    try {
      const db = await openFocusFileDBForPackage();
      const record = await new Promise((resolve, reject) => {
        const tx = db.transaction(FOCUS_FILE_STORE_V34, 'readonly');
        const req = tx.objectStore(FOCUS_FILE_STORE_V34).get(id);
        req.onsuccess = () => resolve(req.result || null);
        req.onerror = () => reject(req.error || new Error('IndexedDB 读取失败'));
      });
      db.close();
      return record && record.blob ? record.blob : null;
    } catch (_) {
      return null;
    }
  }

  function dataUrlToBytes(dataUrl) {
    const text = String(dataUrl || '');
    const comma = text.indexOf(',');
    if (comma < 0) return new Uint8Array(0);
    const meta = text.slice(0, comma);
    const data = text.slice(comma + 1);
    if (/;base64/i.test(meta)) {
      const binary = atob(data);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
      return bytes;
    }
    return SkillUtils.textToBytes(decodeURIComponent(data));
  }

  async function focusFileToBytes(item) {
    if (item.file) return SkillUtils.fileToBytes(item.file);

    const blob = await getFocusBlobFromDB(item.id);
    if (blob) {
      const buffer = await blob.arrayBuffer();
      return new Uint8Array(buffer);
    }

    if (item.dataUrl) return dataUrlToBytes(item.dataUrl);
    if (item.textContent) return SkillUtils.textToBytes(item.textContent);
    return new Uint8Array(0);
  }

  async function buildPackage(formData, filesByCategory) {
    const manifest = buildManifest(formData, filesByCategory);
    const entries = [];

    const deepLinks = manifest.materials.deep.links;
    const externalLinks = manifest.materials.external.links;
    if (deepLinks.length) entries.push({ name: 'deep_links__d_link_01.md', data: SkillUtils.textToBytes(makeLinkMarkdown('精读链接', deepLinks)) });
    if (externalLinks.length) entries.push({ name: 'external_links__e_link_01.md', data: SkillUtils.textToBytes(makeLinkMarkdown('外部链接', externalLinks)) });

    entries.push({ name: 'START_HERE.md', data: SkillUtils.textToBytes(buildStartHere(formData, manifest)) });

    for (const category of ['docs', 'images', 'data']) {
      for (const item of (filesByCategory[category] || [])) {
        entries.push({ name: itemManifest(item).path, data: await materialFileToBytes(item) });
      }
    }

    const focusFilesForPackage = filesByCategory.effectiveFocusFiles || filesByCategory.focusFiles || [];
    for (const item of focusFilesForPackage) {
      entries.push({ name: itemManifest(item).path, data: await focusFileToBytes(item) });
    }

    return createZipBlob(entries);
  }

  function downloadBlob(blob, fileName) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  window.SkillPackage = { buildPackage, downloadBlob };
})();
