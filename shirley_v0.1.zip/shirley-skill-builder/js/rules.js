(function () {
  'use strict';

  function $(id) { return document.getElementById(id); }

  const RULE_FIELDS = [
    'userRole',
    'aiRole',
    'infoSources',
    'referencesLimit',
    'docStyleFormat',
    'sectionPrinciple',
    'strictNoHallucinationZone',
    'externalInterpretationZone',
    'visualizationPrinciple',
    'formulaRequirements'
  ];

  const IMPORTED_RULE_SKILL_KEY = 'shirley.importedRuleSkill.v1';

  function defaults() {
    return window.SkillForm && SkillForm.getBuiltInRules ? SkillForm.getBuiltInRules() : {
      userRole: '',
      aiRole: '',
      infoSources: '',
      referencesLimit: '',
      docStyleFormat: '',
      sectionPrinciple: '',
      strictNoHallucinationZone: '',
      externalInterpretationZone: '',
      visualizationPrinciple: '',
      formulaRequirements: ''
    };
  }

  function rulesKey() {
    return window.SkillForm && SkillForm.RULES_KEY ? SkillForm.RULES_KEY : 'shirley.customRules.v16';
  }

  function readRules() {
    return RULE_FIELDS.reduce((rules, key) => {
      const node = $(key);
      rules[key] = node ? node.value : '';
      return rules;
    }, {});
  }

  function pickRules(source) {
    const raw = source && typeof source === 'object' ? (source.rules || source.config || source) : {};
    return RULE_FIELDS.reduce((rules, key) => {
      rules[key] = raw && typeof raw[key] === 'string' ? raw[key] : '';
      return rules;
    }, {});
  }

  function mergeWithDefaults(rules) {
    return { ...defaults(), ...Object.fromEntries(Object.entries(rules || {}).filter(([, value]) => String(value || '').trim())) };
  }

  function fillRules(rules) {
    RULE_FIELDS.forEach((key) => {
      const node = $(key);
      if (node) node.value = rules[key] || '';
    });
  }

  function currentRules() {
    return window.SkillForm && SkillForm.getDefaultRules ? SkillForm.getDefaultRules() : defaults();
  }

  function clearInlineMessage() {
    const box = $('rulesMessage');
    if (!box) return;
    box.hidden = true;
    box.textContent = '';
    box.className = 'panel result-panel';
  }

  function activateRuleEditor(target) {
    const editor = document.querySelector(`[data-rule-editor="${target}"]`);
    if (!editor) return;
    const block = editor.closest('.rules-config-block');
    if (!block) return;

    block.querySelectorAll('[data-rule-tab]').forEach((tab) => {
      const active = tab.dataset.ruleTab === target;
      tab.classList.toggle('is-active', active);
      tab.setAttribute('aria-selected', active ? 'true' : 'false');
    });
    block.querySelectorAll('[data-rule-editor]').forEach((panel) => {
      panel.classList.toggle('is-active', panel.dataset.ruleEditor === target);
    });
  }

  function bindRuleTabs() {
    document.querySelectorAll('[data-rule-tab]').forEach((tab) => {
      tab.addEventListener('click', () => activateRuleEditor(tab.dataset.ruleTab));
    });
  }

  function activateSectionZoneEditor(target) {
    const container = document.querySelector('.rule-editor--section-zones');
    if (!container) return;

    container.querySelectorAll('[data-section-zone-tab]').forEach((tab) => {
      const active = tab.dataset.sectionZoneTab === target;
      tab.classList.toggle('is-active', active);
      tab.setAttribute('aria-selected', active ? 'true' : 'false');
    });

    container.querySelectorAll('[data-section-zone-panel]').forEach((panel) => {
      panel.classList.toggle('is-active', panel.dataset.sectionZonePanel === target);
    });
  }

  function bindSectionZoneTabs() {
    document.querySelectorAll('[data-section-zone-tab]').forEach((tab) => {
      tab.addEventListener('click', () => activateSectionZoneEditor(tab.dataset.sectionZoneTab));
    });
  }

  function bindFocusControls() {
    if (!window.SkillForm) return;
    SkillForm.initFocusLibrary();

    const show = (result) => SkillUtils.showAlert(result.message, result.ok ? 'ok' : 'error', result.ok ? '已保存' : '需要补充');
    const save = $('btnSaveFocus');
    const update = $('btnUpdateFocus');
    const clear = $('btnClearFocus');
    if (save) save.addEventListener('click', () => show(SkillForm.addFocusItem()));
    if (update) update.addEventListener('click', () => show(SkillForm.updateFocusItem()));
    if (clear) clear.addEventListener('click', () => show(SkillForm.clearFocusInput()));

    const focusFiles = $('focusFiles');
    if (focusFiles) {
      focusFiles.addEventListener('change', async (event) => {
        const result = await SkillForm.addFocusFiles(event.target.files);
        event.target.value = '';
        const messages = [];
        if (result.textCount) messages.push(`已读取 ${result.textCount} 个文本文件内容，保存配置后会作为默认关注点文件使用。`);
        if (result.fileCount) messages.push(`已添加 ${result.fileCount} 个文件到 focus_uploads。`);
        if (result.errors.length) messages.push(result.errors.join('\n'));
        if (messages.length) {
          await SkillUtils.showAlert(
            messages.join('\n'),
            result.errors.length ? 'error' : 'ok',
            result.errors.length ? '部分文件需要处理' : '关注点已更新'
          );
        }
      });
    }
  }

  function safeRuleFileName(name) {
    return String(name || 'Shirley_自定义规则')
      .replace(/[\\/:*?"<>|]/g, '_')
      .replace(/\s+/g, '_')
      .replace(/_+/g, '_')
      .replace(/^_+|_+$/g, '')
      .slice(0, 96) || 'Shirley_自定义规则';
  }

  function timestampForRuleName() {
    const d = new Date();
    const pad = (n) => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}_${pad(d.getHours())}-${pad(d.getMinutes())}`;
  }

  function exportRules() {
    if (window.SkillForm && SkillForm.persistFocusIfNeeded) SkillForm.persistFocusIfNeeded();

    const stamp = timestampForRuleName();
    const fileName = `Shirley_自定义规则_${stamp}.json`;
    const payload = {
      app: 'Shirley',
      type: 'custom_rules',
      schema_version: 1,
      config_name: `Shirley 自定义规则 ${stamp}`,
      exported_at: new Date().toISOString(),
      rules: readRules(),
      focus_entries: window.SkillForm && SkillForm.getFocusItems ? SkillForm.getFocusItems() : [],
      focus_files: window.SkillForm && SkillForm.getCurrentFocusFiles ? SkillForm.getCurrentFocusFiles() : SkillUtils.readJSON('shirley.focusFiles.v1', [])
    };

    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  function focusTextFromImport(data) {
    const entries = data && (data.focus_entries || data.focusEntries || data.focus_items || data.focusItems);
    if (Array.isArray(entries)) {
      return entries
        .map((item) => typeof item === 'string' ? item : item && item.text)
        .filter((text) => String(text || '').trim())
        .join('\n\n');
    }
    return typeof (data && data.focusText) === 'string' ? data.focusText : '';
  }

  async function importRulesFile(file) {
    if (!file) return;
    try {
      const text = await file.text();
      const data = JSON.parse(text);
      const importedRules = mergeWithDefaults(pickRules(data));
      fillRules(importedRules);
      SkillUtils.writeJSON(rulesKey(), importedRules);

      const focusText = focusTextFromImport(data);
      let focusEntries = [];
      if (window.SkillForm && SkillForm.replaceFocusEntriesFromText) {
        focusEntries = SkillForm.replaceFocusEntriesFromText(focusText);
        if (window.SkillForm.replaceFocusFilesFromImport) SkillForm.replaceFocusFilesFromImport(data.focus_files || data.focusFiles || []);
        if (window.SkillForm.commitFocusEntries) SkillForm.commitFocusEntries();
        const box = $('focusText');
        if (box) box.value = '';
      }

      const stamp = timestampForRuleName();
      const configName = String(data.config_name || data.name || `Shirley 自定义规则 ${stamp}`);
      const fileName = `${safeRuleFileName(configName)}.json`;
      SkillUtils.writeJSON(IMPORTED_RULE_SKILL_KEY, {
        path: `skills/${fileName}`,
        file_name: fileName,
        config_name: configName,
        imported_at: new Date().toISOString(),
        source_file_name: file.name || '',
        rules: importedRules,
        focus_entries: focusEntries,
        focus_files: data.focus_files || data.focusFiles || []
      });

      await SkillUtils.showAlert(`规则已导入，并已保存为本地默认配置。\n\n生成任务包时，该规则会写入：skills/${fileName}`, 'ok', '导入成功');
    } catch (error) {
      await SkillUtils.showAlert(`导入失败：${error && error.message ? error.message : String(error)}`, 'error', '导入失败');
    }
  }

  function bindRuleImportExport() {
    const exportBtn = $('btnExportRules');
    const importBtn = $('btnImportRules');
    const fileInput = $('ruleImportFile');

    if (exportBtn) exportBtn.addEventListener('click', exportRules);
    if (importBtn && fileInput) importBtn.addEventListener('click', () => fileInput.click());
    if (fileInput) {
      fileInput.addEventListener('change', async (event) => {
        await importRulesFile(event.target.files && event.target.files[0]);
        event.target.value = '';
      });
    }
  }


  let savedSnapshot = '';
  let leavingConfirmed = false;
  let handlingPopstate = false;

  function snapshotRulesPage() {
    const rules = readRules();
    const focusText = $('focusText') ? $('focusText').value : '';
    const focusState = window.SkillForm && SkillForm.focusStateSnapshot ? SkillForm.focusStateSnapshot() : '';
    return JSON.stringify({ rules, focusText, focusState });
  }

  function markSavedSnapshot() {
    savedSnapshot = snapshotRulesPage();
  }

  function hasUnsavedChanges() {
    return snapshotRulesPage() !== savedSnapshot;
  }

  function restoreSavedSnapshot() {
    fillRules(currentRules());
    if (window.SkillForm && SkillForm.restoreSavedFocusState) SkillForm.restoreSavedFocusState();
    const box = $('focusText');
    if (box) box.value = '';
    markSavedSnapshot();
  }

  async function confirmLeaveWithUnsavedChanges() {
    if (!hasUnsavedChanges()) return true;
    const ok = await SkillUtils.showConfirm('存在尚未保存的内容，确定返回？', '存在尚未保存的内容');
    if (ok) restoreSavedSnapshot();
    return ok;
  }

  async function goHomeWithGuard() {
    if (leavingConfirmed) {
      window.location.href = 'index.html';
      return;
    }
    const ok = await confirmLeaveWithUnsavedChanges();
    if (!ok) return;
    leavingConfirmed = true;
    window.location.href = 'index.html';
  }

  function bindBrowserBackGuard() {
    try {
      window.history.replaceState({ shirleyRulesGuardBase: true }, '', window.location.href);
      window.history.pushState({ shirleyRulesGuard: true }, '', window.location.href);
      window.addEventListener('popstate', async () => {
        if (leavingConfirmed || handlingPopstate) return;
        handlingPopstate = true;
        const ok = await confirmLeaveWithUnsavedChanges();
        if (ok) {
          leavingConfirmed = true;
          window.location.href = 'index.html';
        } else {
          window.history.pushState({ shirleyRulesGuard: true }, '', window.location.href);
          handlingPopstate = false;
        }
      });
    } catch (_) {
      /* History API may be unavailable in strict local contexts. */
    }
  }

  document.addEventListener('DOMContentLoaded', () => {
    clearInlineMessage();
    fillRules(currentRules());
    bindRuleTabs();
    bindSectionZoneTabs();
    bindFocusControls();
    bindRuleImportExport();

    if (window.SkillUtils && SkillUtils.bindPatrickLove) SkillUtils.bindPatrickLove();
    markSavedSnapshot();
    bindBrowserBackGuard();

    const backHome = $('btnBackHome');
    if (backHome) backHome.addEventListener('click', goHomeWithGuard);

    $('btnSaveRules').addEventListener('click', async () => {
      if (window.SkillForm && SkillForm.persistFocusIfNeeded) SkillForm.persistFocusIfNeeded();
      if (window.SkillForm && SkillForm.commitFocusEntries) SkillForm.commitFocusEntries();
      SkillUtils.writeJSON(rulesKey(), readRules());
      markSavedSnapshot();
      await SkillUtils.showAlert('配置已保存，并会作为本地默认配置使用。主页直接生成任务包时会自动采用该配置。', 'ok', '配置已保存');
    });

    $('btnResetRules').addEventListener('click', async () => {
      const ok = await SkillUtils.showConfirm('确定要恢复默认配置吗？这会清除当前浏览器中保存的自定义配置，并将重点关注恢复为空。', '恢复默认');
      if (!ok) return;
      SkillUtils.storageRemove(rulesKey());
      SkillUtils.storageRemove('shirley.customRules.v2');
      SkillUtils.storageRemove(IMPORTED_RULE_SKILL_KEY);
      SkillUtils.storageRemove('shirley.focusFiles.v1');
      if (window.SkillForm && SkillForm.restoreBuiltInFocusDefaults) {
        SkillForm.restoreBuiltInFocusDefaults();
        if (window.SkillForm.replaceFocusFilesFromImport) SkillForm.replaceFocusFilesFromImport([]);
        if (window.SkillForm.clearDefaultFocusDraft) SkillForm.clearDefaultFocusDraft();
        const box = $('focusText');
        if (box) box.value = '';
      }
      fillRules(defaults());
      markSavedSnapshot();
      await SkillUtils.showAlert('已恢复内置默认配置。', 'ok', '已恢复');
    });
  });
})();
