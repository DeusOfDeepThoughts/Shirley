(function () {
  'use strict';

  function $(id) { return document.getElementById(id); }

  function clearInlineMessages() {
    const upload = $('uploadMessage');
    if (upload) {
      upload.hidden = true;
      upload.textContent = '';
      upload.className = 'message';
    }
    const result = $('resultBox');
    if (result) {
      result.hidden = true;
      result.textContent = '';
      result.className = 'panel result-panel';
    }
  }

  function bindFileInput(inputId, category) {
    const input = $(inputId);
    if (!input) return;
    input.addEventListener('change', async (event) => {
      clearInlineMessages();
      const errors = await SkillForm.addFiles(event.target.files, category);
      event.target.value = '';
      if (errors.length) {
        await SkillUtils.showAlert(errors.join('\n'), 'error', '文件类型需要调整');
      }
    });
  }

  function bindLinkModule() {
    const btn = $('btnAddLinks');
    const box = $('linkInput');
    if (!btn || !box) return;
    btn.addEventListener('click', async () => {
      clearInlineMessages();
      const result = SkillForm.addLinks(box.value);
      if (result.added > 0) box.value = '';
      const lines = [];
      if (result.added) lines.push(`已添加 ${result.added} 条链接材料。`);
      if (result.errors.length) lines.push(result.errors.join('\n'));
      await SkillUtils.showAlert(
        lines.join('\n') || '没有添加新的链接材料。',
        result.errors.length ? 'error' : 'ok',
        result.errors.length ? '部分链接需要调整' : '链接已添加'
      );
    });
  }

  function bindFocusButtons() {
    const show = (result) => SkillUtils.showAlert(result.message, result.ok ? 'ok' : 'error', result.ok ? '已保存' : '需要补充');
    $('btnSaveFocus').addEventListener('click', () => show(SkillForm.addFocusItem()));
    $('btnUpdateFocus').addEventListener('click', () => show(SkillForm.updateFocusItem()));
    $('btnClearFocus').addEventListener('click', () => show(SkillForm.clearFocusInput()));

    const focusFiles = $('focusFiles');
    if (focusFiles) {
      focusFiles.addEventListener('change', async (event) => {
        clearInlineMessages();
        const result = await SkillForm.addFocusFiles(event.target.files);
        event.target.value = '';
        const messages = [];
        if (result.textCount) messages.push(`已读取 ${result.textCount} 个文本文件内容，生成时会写入 START_HERE。`);
        if (result.fileCount) messages.push(`已添加 ${result.fileCount} 个文件到 focus_uploads。`);
        if (result.errors.length) messages.push(result.errors.join('\n'));
        if (messages.length) {
          await SkillUtils.showAlert(
            messages.join('\n'),
            result.errors.length ? 'error' : 'ok',
            result.errors.length ? '部分文件需要处理' : '关注点已更新'
          );
        }
      });
    }
  }

  async function handleGenerate() {
    clearInlineMessages();
    SkillForm.persistFocusIfNeeded();
    const formData = SkillForm.readForm();
    const missing = SkillForm.validateRequired(formData);
    if (missing.length) {
      await SkillUtils.showAlert(`请先补充必填项：${missing.join('、')}。`, 'error', '信息不完整');
      return;
    }

    const button = $('btnGenerate');
    const oldText = button.textContent;
    button.disabled = true;
    button.textContent = '正在生成...';

    try {
      const blob = await SkillPackage.buildPackage(formData, SkillForm.state);
      const fileName = `Shirley_Task_Package_${SkillUtils.timestampForName()}.zip`;
      SkillPackage.downloadBlob(blob, fileName);
      await SkillUtils.showAlert(
        `已生成并开始下载：${fileName}\n\n下载路径：浏览器默认下载文件夹。通常是“下载 / Downloads”；Edge 或 Chrome 可按 Ctrl + J 查看准确保存位置。\n\n对于ChatGPT等支持zip格式的AI，通常直接上传 zip；
对于Kimi等不支持zip格式的AI，需解压后上传文件内全部材料。`,
        'ok',
        '任务包已生成'
      );
    } catch (error) {
      console.error(error);
      await SkillUtils.showAlert(`生成失败：${error && error.message ? error.message : String(error)}`, 'error', '生成失败');
    } finally {
      button.disabled = false;
      button.textContent = oldText;
    }
  }

  document.addEventListener('DOMContentLoaded', () => {
    if (window.SkillUtils && SkillUtils.bindPatrickLove) SkillUtils.bindPatrickLove();
    SkillForm.initFocusLibrary();
    SkillForm.initRuleMode();
    SkillForm.initMaterialControls();
    SkillForm.initMaterialSelectors();

    bindFileInput('docFiles', 'docs');
    bindFileInput('imageFiles', 'images');
    bindFileInput('dataFiles', 'data');
    bindLinkModule();
    bindFocusButtons();

    $('btnGenerate').addEventListener('click', handleGenerate);
    $('btnReset').addEventListener('click', async () => {
      const ok = await SkillUtils.showConfirm('确定要清空当前表单、已选择文件和本次关注点吗？默认配置不会被删除。', '清空本次填写');
      if (!ok) return;
      SkillForm.resetAll();
      clearInlineMessages();
      await SkillUtils.showAlert('当前表单和已选择文件已清空。', 'ok', '已清空');
    });
  });
})();
