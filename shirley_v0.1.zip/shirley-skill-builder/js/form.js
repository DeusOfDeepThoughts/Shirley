(function () {
  'use strict';

  const IMAGE_EXT = new Set(['png', 'jpg', 'jpeg', 'webp', 'gif', 'bmp', 'svg', 'tif', 'tiff']);
  const DOC_EXT = new Set(['pdf', 'doc', 'docx', 'txt', 'md', 'rtf', 'tex', 'ppt', 'pptx', 'odt', 'odp']);
  const DATA_EXT = new Set(['csv', 'tsv', 'json', 'jsonl', 'xlsx', 'xls', 'xml', 'yaml', 'yml', 'parquet', 'feather', 'arrow', 'npy', 'npz', 'pkl', 'pickle', 'sqlite', 'db', 'sql']);

  const FOCUS_TEXT_EXT = new Set(['txt', 'md', 'markdown', 'tex', 'rst', 'log']);
  const FOCUS_FILE_EXT = new Set(['txt', 'md', 'markdown', 'tex', 'rst', 'log', 'pdf', 'doc', 'docx', 'rtf', 'ppt', 'pptx', 'odt', 'odp', 'json', 'yaml', 'yml', 'csv', 'png', 'jpg', 'jpeg', 'webp', 'gif', 'bmp', 'svg', 'tif', 'tiff']);

  const OLD_FOCUS_KEY = 'shirley.focusItems.v1';
  const FOCUS_LIBRARY_KEY = 'shirley.focusLibrary.v7';
  const RULES_KEY = 'shirley.customRules.v16';
  const LEGACY_RULES_KEY = 'shirley.customRules.v2';

  const BUILTIN_RULES = {
    userRole: "用户是需要理解、整理或复核科研材料的研究者、学生或项目成员。请根据用户提供的重点关注和素材组织回答。默认面向科研阅读与学习场景。",
    aiRole: "你是一个严格、清晰、面向科研任务的论文精读助手。目标是根据用户提供的精读材料、外部材料和重点关注内容，生成结构化、可复核、适合科研工作者使用的结果。",
    infoSources: "严格无幻觉区只能使用以下来源：\n\n1）材料清单中 deep_materials 精读材料类别下的原论文正文。\n2）材料清单中 deep_materials 精读材料类别下原论文的图、表、公式、算法框、脚注、附录和补充材料。\n3）原论文 References 列表中的文献信息。\n4）用户额外提供的 References 文献全文或可核验内容。\n5）材料清单中 focus_uploads 重点关注附件下用户明确要求重点关注的内容。\n\n所有来自严格无幻觉区的事实，都必须能回到具体材料位置。不能只写“原论文”“论文中提到”“见原文”等笼统出处。",
    referencesLimit: "如果用户只提供了 References 条目，而没有提供该参考文献正文，则只能使用该条目的作者、标题、年份、会议或期刊等元信息。\n\n不得根据论文标题、常识、模型记忆或外部印象推测该文献的具体内容。\n\n如果需要提到参考文献的作用，必须区分三种情况：\n1）原论文正文明确说明了该文献的作用。\n2）原论文只列出了该文献，但没有描述其内容。\n3）用户额外提供了该参考文献正文，因此可以总结其内容。\n\n引用 References 时，出处也必须可追踪：\n1）只来自原论文 References 列表：写 Reference 编号、标题、作者/年份，以及“正文未提供该文献内容”。\n2）来自用户额外上传的参考文献全文：写材料路径、页码、章节标题、段落位置和定位短句。",
    externalInterpretation: "1. 本区域用于帮助读者理解，可以包含大白话解释、方法直觉、背景知识、与经典方法的关系、工程实现提示、复现建议、批判性分析、潜在风险和外部知识辅助图示。\n2. 如果材料清单中 external_materials 外部材料类别下存在资料，优先使用该类别下的资料进行解读。\n3. 不得把外部图示、外部类比、外部推测及 external_materials 外部材料类别下的资料内容混入严格无幻觉区。\n\n外部解读的信息来源比例：\n1）如果 AI 环境支持联网检索，外部解读区必须主动进行网络检索，不得只依赖模型训练数据。\n2）当 external_materials 存在且可读取、且 AI 也支持联网检索时，外部解读区的外部依据建议按以下比例组织：\n   - external_materials：约 40% 到 60%；\n   - 网络检索资料：约 30% 到 45%；\n   - 其他知识源或模型自身辅助解释：约 0% 到 20%。\n3）如果 external_materials 信息不足，但 AI 支持联网检索，则网络检索资料应提升到约 50% 到 70%。\n4）如果 AI 不支持联网检索，必须明确说明“当前环境不支持联网检索”，不得伪造网络来源；此时应优先使用 external_materials，并谨慎补充模型辅助解读。\n5）模型自身解释只能作为辅助，不能替代 external_materials 或网络检索资料。\n6）如果某一外部解读判断主要来自模型自身解释，应标注“模型辅助解读，非原文事实”。\n\n网络检索要求：\n1）网络检索应优先选择高质量来源，例如官方文档、教材、综述论文、权威机构页面、开源项目文档、标准规范、数据库说明、学术机构材料。\n2）不要用低质量营销文章、无来源博客、论坛碎片信息替代权威资料。\n3）每个来自网络的关键解释都必须标注引用源。\n4）网络来源出处应包含：网页标题或资料名、发布机构或作者、链接或可检索标识、访问日期、定位短句。\n5）网络资料只能放在外部解读区，不得写进严格无幻觉区。\n\nexternal_materials 出处要求：\n1）引用 external_materials 时，应使用独立出处块，不要把出处接在解读文字后面。\n2）出处块应尽量包含：文件名、材料类别、PDF 页码或章节位置、段落位置、定位短句。\n3）不得把 external_materials 的内容写进严格无幻觉区。\n\n外部解读区的图解要求：\n1）外部解读区也要适当使用图解，不得全是文字。\n2）完整精读报告中，外部解读区通常应至少包含 1 到 2 个“外部解读示意图”。\n3）如果外部解读涉及机制、流程、类比、工程实现、复现路线或知识背景，应优先考虑图解。\n4）外部解读图可以根据 external_materials、网络检索资料和模型辅助解释综合绘制，但必须标注“外部解读示意图”，不得作为原文事实依据。\n5）若图解来自网络图片或外部材料图片，必须标注来源；若是自绘图，必须说明“根据外部资料与辅助解释整理”。\n\n排版要求：\n1）外部解读区必须用清楚标题标出，不得伪装成原文内容。\n2）外部解读区不要和严格无幻觉区挤在一起。\n3）每段解读尽量短。\n4）重要内容可以加粗，也可以使用“理解”“复现”“风险”“启发”等提示词，但这些提示词不是硬性模板。\n5）如果引用外部材料或网络材料，也要单独给出处块，不要把出处接在解读文字后面。\n6）不要使用 HTML 的 div、span、br、style 等标签制作颜色块或卡片。\n7）如果只是经验判断或常识解释，应标注确定性：高、中或低。\n\n推荐出处写法：\n\n> 外部材料出处\n> 文件：文件名__e_doc_01.pdf\n> 类别：external_materials 外部材料\n> 位置：PDF 第 4 页；§2.1；第 1 段\n> 定位短句：“...”\n\n> 网络资料出处\n> 标题：资料标题\n> 来源：机构 / 作者 / 网站\n> 链接或检索标识：...\n> 访问日期：YYYY-MM-DD\n> 定位短句：“...”",
    docStyleFormat: "整体风格：\n输出应清晰、舒展、有层次，避免整篇都是黑色连续文字。报告要适合科研阅读，也要方便快速定位重点。\n\n默认格式要求：\n1）默认使用 Markdown，不要输出原始 HTML 标签。\n2）不要使用 <div>、<span>、<br>、style 等 HTML 标签来做排版或颜色。\n3）如果用户明确要求 HTML 版报告，才可以使用 HTML；否则一律使用 Markdown。\n4）如果某个平台不支持颜色，就用 Markdown 加粗、引用块、分隔线、编号和表格来表达层次。\n\n推荐排版：\n1）每个大章节使用清楚的小标题。\n2）每个段落尽量短，避免超过 5 行。\n3）重要文字可以加粗，但不要每句话都加粗。\n4）论文出处必须另起块展示，不要直接接在正文或解读句子后面。\n5）严格无幻觉区和外部解读区要通过标题、空行、引用块或分隔线明显区分。\n6）重点、难点、主线、风险、复现等提示可以使用，但由 AI 根据内容动态判断，不是每节必须机械套用。\n7）报告不能全篇只有文字。凡是方法结构、实验结果、数据对比、公式或流程适合可视化，应主动使用表格、公式块、原文图讲解或自绘图。\n8）如果图示明显比纯文字更能讲清楚，就不要只写文字；应选择 Mermaid、ASCII、表格、公式块或原文图讲解。\n\n可使用的稳定 Markdown 样式：\n1）重要句子：使用 **加粗**。\n2）特别提醒：使用引用块，例如：\n> 提醒：这里写需要注意的内容。\n\n3）出处块：使用引用块，例如：\n> 论文出处\n> 文件：文件名__d_doc_01.pdf\n> 位置：PDF 第 5 页，§3 Method，第 2 段\n> 定位短句：“adaptive threshold mechanism”\n\n4）结构对比：使用表格。\n5）流程说明：使用编号列表、简单 ASCII 图或稳定 Mermaid 图。\n6）图表说明：使用“图像讲解”“表格解读”“公式解释”等小标题。\n\n动态强调原则：\n1）AI 可以判断哪些内容需要突出。\n2）可以把它认为重要的句子、段落或关键词加粗。\n3）可以使用“重点”“难点”“风险”等字眼，但不是硬性要求。\n4）不需要强迫每个章节都标出重点或难点。\n5）即使没有写“难点”两个字，只要把真正重要或困难的内容用排版突出，也是允许的。\n\n避免：\n1）避免大段连续黑色文字。\n2）避免大量 HTML 标签污染 Markdown 文档。\n3）避免过度彩色化或装饰化。\n4）避免标签泛滥。\n5）避免为追求形式而牺牲准确性。\n6）避免因为担心可视化出错而让报告完全没有图、表、公式或流程图。",
    sectionPrinciple: "每个主要章节必须按照“重点关注”中的章节顺序组织，不得自行改成另一套章节框架。\n\n强制要求：\n1）输出结构必须覆盖“重点关注”中列出的每一章。\n2）每一章都必须包含“严格无幻觉区”和“外部解读区”两个子区。\n3）不能只写严格无幻觉区而省略外部解读区。\n4）不能只写外部解读区而省略严格无幻觉区。\n5）不能脱离“重点关注”中的章节顺序另起一套大纲。\n6）如果某一章原文信息不足，严格无幻觉区写“原文未提供”或“原文未提供足够信息”，外部解读区仍需说明可理解的背景、可能影响、学习提示或待补充问题。\n7）若用户上传了新的重点关注内容，应以用户上传或编辑后的重点关注章节为准。\n\n严格无幻觉区负责回答“原文到底说了什么”，必须给出可定位出处。\n外部解读区负责回答“这件事如何理解、为什么重要、可能有什么启发”，必须明确标注为外部解读。\n\n推荐每章内部排版：\n1）章标题沿用“重点关注”中的章节标题。\n2）先给一个简短小结，说明本章解决什么阅读问题。\n3）再写“严格无幻觉区”，事实与出处分离排版。\n4）再写“外部解读区”，解释、类比、批判、启发和外部材料辅助解读单独成区。\n5）涉及方法、结构、流程、实验结果或公式时，必须主动考虑插入原文图讲解、自绘图、表格或公式块。\n6）重要内容可以用加粗、引用块、编号、表格或简洁图示突出。\n\n注意：\n1）不要把“论文出处”直接挤在解读句子后面。\n2）出处应另起一块，建议使用 Markdown 引用块。\n3）不要为了做颜色或卡片效果而输出大量 HTML 标签。\n4）“重点”“难点”“主要”“风险”等标签不是硬性模板，AI 可以根据内容动态决定是否使用。\n5）事实与解读必须分离，出处也必须独立成块。\n6）不能因为可视化限制而完全取消图、表、公式或流程图；应在安全边界内合理使用。",
    strictNoHallucinationZone: "本区域只写可从原论文或已提供参考文献中核验的信息。\n\n核心要求：\n1）可以用 AI 总结，但必须忠实原意。\n2）不得加入常识推断。\n3）不得补全原文没说的信息。\n4）不得美化、拔高或替作者解释。\n5）如果原文没有提供，直接写“原文未提供”。\n6）严格无幻觉区所有事实、数据、变量含义、实验结论和方法描述，只能来自材料清单中 deep_materials 精读材料类别下的文件，或用户明确提供的可核验材料。\n7）不得用整页截图、大段文字截图或连续页面截图代替原文总结。\n8）可以使用原文中的图、表、公式和流程图，但必须是必要的局部内容，并配套解释与出处。\n\n出处排版要求：\n1）每个关键事实后必须给出可定位出处。\n2）出处必须单独成块，不要直接接在句子后面。\n3）出处块与正文之间至少空一行。\n4）出处块建议使用 Markdown 引用块或“论文出处”小标题。\n5）出处块应拆成多行字段，不要写成一长串文字。\n6）不要使用 HTML 的 div、span、br、style 等标签制作出处卡片。\n7）同一事实如果有多个来源，使用多条出处，不要合并成一团。\n\n推荐出处块格式：\n\n> 论文出处\n> 文件：文件名__d_doc_01.pdf\n> 位置：PDF 第 3 页；§2 Method；第 2 段\n> 对象：Figure 2 / Table 1 / 公式 (4) / 正文段落\n> 定位短句：“adaptive threshold mechanism”\n\n出处内容要求：\n1）出处不能只写“原论文”“论文中”“文中提到”“见 Figure 2”。\n2）出处必须尽量包含：材料路径、PDF 页码或文档页码、章节标题、段落位置、图表/公式编号、定位短句。\n3）如果 PDF 页码和论文印刷页码不同，优先写 PDF 页码；如果能看到印刷页码，可同时写。\n4）如果无法确定页码，必须写清楚可定位的章节标题、段落序号或附近小标题。\n5）如果只是根据图、表、公式、算法框得出结论，必须写明 Figure/Table/Equation/Algorithm 编号和图注、表头或公式附近文字。\n6）如果是根据 References 条目，只能写该条目的元信息，并明确说明正文未提供该文献内容。\n7）如果一句话综合了多处信息，必须列出多个出处；不能只给一个笼统出处。\n8）每条出处至少包含一个原文定位短句。定位短句应是原文中的关键词或短语，长度控制在 5 到 25 个词，方便用户用搜索功能找到原文位置。\n9）如果找不到可定位出处，不要把该内容写进严格无幻觉区。\n\n截图与摘录限制：\n1）不得整页截图。\n2）不得用大段原文文字截图顶替分析。\n3）不得连续粘贴多页截图。\n4）不得大段复制原文正文。\n5）必要时只能使用短摘录或局部图像，并说明为什么需要保留原貌。\n6）如果需要引用原文措辞，只引用最短必要短语，并给出可定位出处。\n\n层次与强调：\n1）严格无幻觉区也要有层次，但不要机械规定哪些内容必须叫“重点”“难点”或“主要”。\n2）AI 应根据内容的重要性动态决定是否加粗、编号、分块或使用简短提示词。\n3）可以把真正重要的句子加粗。\n4）可以使用“重点”“难点”“风险”等提示词，但这不是硬性要求。\n5）没有使用这些提示词也可以，只要重要内容被清楚突出即可。\n6）出处块统一放在相关事实后面，不要与解读混成一段。\n\n原文图处理：\n1）如果原文中出现关键图、表、流程图、公式图或结果图，即使无法直接插入到对应位置，也必须标注其位置并解释其作用。\n2）最好能把原图或必要局部放到文档中对应位置，然后紧接着解释。\n3）如果无法插图，应写清楚“此处应对应原文 Figure/Table/Equation X”，并说明其位置、内容和为什么重要。\n4）不要因为不能直接插图就完全忽略原文图。\n\n输出检查：\n1）严格无幻觉区完成后，逐条检查关键事实是否都有可定位出处。\n2）如果某条结论只有模糊出处，改写为更保守的表达，或标注“原文未提供可定位依据”。\n3）检查是否存在整页截图、大段正文截图或用截图堆篇幅的情况；如果存在，必须删除并改为总结加出处。\n4）检查公式是否使用规范 LaTeX 格式；如果公式格式可能无法渲染，应改为更稳定的写法。\n5）检查是否遗漏了原文中对理解非常关键的图、表、公式或流程图。\n6）不要把外部知识、经验判断、类比解释放入严格无幻觉区。\n\n可视化不得缺席：\n1）如果严格无幻觉区涉及原文 Figure、Table、Algorithm 或 Equation，应在对应位置标注并解释。\n2）如果无法插入原图，也必须给出“原文图表位置”块并解释图中核心信息。\n3）如果原文有实验结果表，应至少整理关键结果为 Markdown 表格。\n4）如果原文有关键公式，应至少转写并解释核心公式。\n5）如果原文描述了流程或结构，应考虑用简洁自绘图整理，但必须注明根据原文描述整理。",
    externalInterpretationZone: "1. 本区域用于帮助读者理解，可以包含大白话解释、方法直觉、背景知识、与经典方法的关系、工程实现提示、复现建议、批判性分析、潜在风险和外部知识辅助图示。\n2. 如果材料清单中 external_materials 外部材料类别下存在资料，优先使用该类别下的资料进行解读。\n3. 不得把外部图示、外部类比、外部推测及 external_materials 外部材料类别下的资料内容混入严格无幻觉区。\n\n外部解读的信息来源比例：\n1）如果 AI 环境支持联网检索，外部解读区必须主动进行网络检索，不得只依赖模型训练数据。\n2）当 external_materials 存在且可读取、且 AI 也支持联网检索时，外部解读区的外部依据建议按以下比例组织：\n   - external_materials：约 40% 到 60%；\n   - 网络检索资料：约 30% 到 45%；\n   - 其他知识源或模型自身辅助解释：约 0% 到 20%。\n3）如果 external_materials 信息不足，但 AI 支持联网检索，则网络检索资料应提升到约 50% 到 70%。\n4）如果 AI 不支持联网检索，必须明确说明“当前环境不支持联网检索”，不得伪造网络来源；此时应优先使用 external_materials，并谨慎补充模型辅助解读。\n5）模型自身解释只能作为辅助，不能替代 external_materials 或网络检索资料。\n6）如果某一外部解读判断主要来自模型自身解释，应标注“模型辅助解读，非原文事实”。\n\n网络检索要求：\n1）网络检索应优先选择高质量来源，例如官方文档、教材、综述论文、权威机构页面、开源项目文档、标准规范、数据库说明、学术机构材料。\n2）不要用低质量营销文章、无来源博客、论坛碎片信息替代权威资料。\n3）每个来自网络的关键解释都必须标注引用源。\n4）网络来源出处应包含：网页标题或资料名、发布机构或作者、链接或可检索标识、访问日期、定位短句。\n5）网络资料只能放在外部解读区，不得写进严格无幻觉区。\n\nexternal_materials 出处要求：\n1）引用 external_materials 时，应使用独立出处块，不要把出处接在解读文字后面。\n2）出处块应尽量包含：文件名、材料类别、PDF 页码或章节位置、段落位置、定位短句。\n3）不得把 external_materials 的内容写进严格无幻觉区。\n\n外部解读区的图解要求：\n1）外部解读区也要适当使用图解，不得全是文字。\n2）完整精读报告中，外部解读区通常应至少包含 1 到 2 个“外部解读示意图”。\n3）如果外部解读涉及机制、流程、类比、工程实现、复现路线或知识背景，应优先考虑图解。\n4）外部解读图可以根据 external_materials、网络检索资料和模型辅助解释综合绘制，但必须标注“外部解读示意图”，不得作为原文事实依据。\n5）若图解来自网络图片或外部材料图片，必须标注来源；若是自绘图，必须说明“根据外部资料与辅助解释整理”。\n\n排版要求：\n1）外部解读区必须用清楚标题标出，不得伪装成原文内容。\n2）外部解读区不要和严格无幻觉区挤在一起。\n3）每段解读尽量短。\n4）重要内容可以加粗，也可以使用“理解”“复现”“风险”“启发”等提示词，但这些提示词不是硬性模板。\n5）如果引用外部材料或网络材料，也要单独给出处块，不要把出处接在解读文字后面。\n6）不要使用 HTML 的 div、span、br、style 等标签制作颜色块或卡片。\n7）如果只是经验判断或常识解释，应标注确定性：高、中或低。\n\n推荐出处写法：\n\n> 外部材料出处\n> 文件：文件名__e_doc_01.pdf\n> 类别：external_materials 外部材料\n> 位置：PDF 第 4 页；§2.1；第 1 段\n> 定位短句：“...”\n\n> 网络资料出处\n> 标题：资料标题\n> 来源：机构 / 作者 / 网站\n> 链接或检索标识：...\n> 访问日期：YYYY-MM-DD\n> 定位短句：“...”",
    visualizationPrinciple: "图像、图表与可视化总原则：\n可视化是论文精读报告的必要组成部分，不是装饰，也不是可有可无。不能因为担心幻觉就完全不做图、表、公式或原文图讲解。可视化要服务理解：非必要处不要加图，但只要图示明显比纯文字更能讲清楚，就必须加入图示。\n\n硬性底线：\n1）除非原文完全没有图、表、公式、流程、结构关系、实验结果和可整理数据，否则报告中不能零可视化。\n2）较完整的论文精读报告，至少应包含 4 类可视化或半可视化内容：\n   A. 原文图 / 表 / 公式 / 算法框中的至少 1 个讲解；\n   B. AI 根据原文整理的至少 1 个 Markdown 表格；\n   C. AI 根据原文绘制的至少 1 个 Mermaid 图或 ASCII 图；\n   D. 外部解读区至少 1 个“外部解读示意图”或外部知识图解。\n3）如果论文包含方法流程、模型结构、训练流程、推理流程、实验流程、数据处理流程、变量关系或机制链条，完整报告中自绘图通常不应少于 2 个。\n4）如果报告篇幅较长或章节较多，自绘图建议 3 到 6 个；短报告可以 1 到 2 个。\n5）如果确实无法插入原图，也必须在相应位置标注原图位置并解释，不得直接跳过。\n6）如果原文没有任何图表公式，也必须用表格、流程图或结构化列表整理关键信息，并说明“原文未提供图表公式”。\n\n新增必须可视化项目：\n1）全文脉络 / 结构图 / 知识脑图：必须在合适位置绘制。用于帮助读者把论文的问题、方法、实验、结论、局限、启发串联起来。优先使用 Mermaid mindmap、Mermaid flowchart 或清晰的 ASCII 知识脑图。\n2）文章引用图：必须在合适位置绘制。用于展示本文与关键参考文献、相关方法、理论来源、数据来源或技术路线之间的关系。可使用 Mermaid graph、flowchart、关系图或 Markdown 表格 + 简图。若原文只提供 References 而未说明引用关系，必须标注“引用关系仅能根据原文正文明确提及部分整理，References 未描述内容不得推断”。\n3）研究内容发展时间线：只要论文涉及明确的研究背景、方法演进、领域发展、技术路线或重要前序工作，就应绘制发展时间线。优先使用 Mermaid timeline；如平台不支持 Mermaid timeline，则使用 Markdown 表格或 ASCII 时间线。时间线必须标注信息来源，不能根据模型记忆随意补年份。\n\n三类新增图示的边界：\n1）全文结构图和知识脑图是必须项，不得省略。\n2）文章引用图是必须项；如果原文没有足够引用关系信息，也要给出“可确认引用关系图”或“引用信息不足说明图”。\n3）发展时间线应在合适位置绘制；如果原文和外部资料都无法支持时间线，应明确说明“当前材料不足以绘制可靠发展时间线”，不能编造。\n4）上述图示可以放在报告前部、方法章节、相关工作章节、外部解读区或总结章节，但必须服务理解，不要堆在一起凑数量。\n\n何处必须优先考虑图示：\n方法整体架构；模型模块关系；输入输出关系；数据流；训练流程；推理流程；核心算法步骤；损失函数组成；实验流程；主实验结果；消融实验；失败案例；论文整体结构；关键公式；变量定义；多方法对比；多数据集多指标结果；外部背景机制；工程复现流程。\n\n何处不应强行加图：\n简单元数据；一句话即可说清的研究动机；没有结构关系的普通事实；原文没有足够依据的结构想象；重复表达同一信息的装饰图；为了凑数量而画的空泛图。\n\nMermaid 与 ASCII 的均衡使用：\n1）Mermaid 和 ASCII 都是允许且重要的绘图方式，不能只用 ASCII，也不能完全不用 Mermaid。\n2）完整精读报告中，只要平台支持 Mermaid，至少应出现 1 个 Mermaid 图。\n3）如果同时适合 Mermaid 和 ASCII，优先用 Mermaid 表示清晰流程、模块结构、因果关系、训练/推理管线；优先用 ASCII 表示小型局部机制、输入输出对照、层级关系、简短概念图。\n4）完整报告中自绘图的推荐比例：Mermaid 约 40% 到 60%，ASCII 或 Markdown 结构图约 40% 到 60%。不需要机械平均，但不能长期只偏向一种。\n5）如果 Mermaid 语法可能出错，应简化 Mermaid，而不是直接放弃 Mermaid。\n6）只有在平台明确不支持 Mermaid 或用户要求纯文本时，才主要使用 ASCII；此时必须说明原因。\n\nMermaid 绘图要求：\n1）优先使用 flowchart TD、flowchart LR、sequenceDiagram 等稳定语法。\n2）节点文字要短，避免过长句子、复杂符号、HTML、LaTeX 和特殊标点。\n3）不要在 Mermaid 节点中放大段论文原文。\n4）Mermaid 图后必须配套文字解释和出处说明。\n5）严格无幻觉区的 Mermaid 图只能根据原文明确描述绘制；外部解读区的 Mermaid 图必须标注“外部解读示意图”。\n\nASCII 绘图要求：\n1）ASCII 图适合表达小型流程、输入输出、层级、对照和局部机制。\n2）ASCII 图应保持简洁，不要画成难以阅读的大块字符。\n3）ASCII 图后必须配套解释。\n4）严格无幻觉区的 ASCII 图必须基于原文明确描述；外部解读区的 ASCII 图必须标注“外部解读示意图”。\n\n原文图片与截图处理：\n1）如果 AI 直接在对话中生成精读内容，应根据当前 AI 平台能力判断是否能展示原文图片；如果支持展示，应尽量在对应位置展示原文图或必要局部；如果不支持展示，应引用原图位置并解释。\n2）如果 AI 是生成 Markdown 文件或 Markdown 报告，则在引用原文图、原文截图或局部截图进行讲解时，只要图像可以从上传材料中获得或抽取，就必须在 Markdown 中插入图片，不要只做文字引用。\n3）Markdown 插图应使用稳定写法，例如：![Figure 2 模型结构](相对路径或图片文件名)。\n4）如果无法抽取或保存图片，必须明确写明“当前环境无法直接抽取/插入该图”，并给出原文图表位置、页码、图注或定位短句，再用文字和自绘图辅助解释。\n5）严禁把原论文整页截图直接放进输出结果。\n6）严禁截取大段正文文字图片来代替总结、分析或出处。\n7）只允许使用必要局部，例如单张原文图、单个公式、单个流程图或必要的局部表格。\n\n输出中必须加入“可视化索引”：\n在报告前部或相关章节前，列出本报告使用了哪些可视化内容，例如：\n- 原文 Figure 2：模型结构图；已插入 / 已讲解 / 无法插入但已标注位置。\n- 原文 Table 1：主实验结果；已整理为 Markdown 表格。\n- Mermaid 图 1：方法流程示意图；根据原文 §3 明确描述整理。\n- ASCII 图 1：输入输出关系；根据原文 §2 整理。\n- 外部解读图 1：机制直觉示意图；仅用于辅助理解。\n\n表格最低要求：\n如果论文包含实验结果、数据集、对比方法、消融实验、变量定义或复现信息，应至少整理 1 个 Markdown 表格。\n表格要服务理解，不要把原文大表完整复制成过长表格；优先摘取核心行列并说明取舍。\n\n公式最低要求：\n如果论文有关键公式，应至少选择核心公式进行规范 LaTeX 转写和变量解释。\n不要用整页截图展示公式。\n如果公式太复杂无法可靠转写，可以使用公式局部截图，但必须只截公式本身，并给出出处。\n\n外部解读可视化：\n1）外部解读区不能全是文字，也应按比例加入图解。\n2）完整报告中，外部解读区通常至少 1 到 2 个外部解读示意图。\n3）外部解读图可用于解释背景机制、经典方法关系、工程流程、复现路线、风险路径或概念类比。\n4）外部解读图必须标注“外部解读示意图”，不得作为原文事实依据。\n5）如果图解依据来自 external_materials 或网络资料，必须标注来源。\n\n版式增强要求：\n1）精读报告在合适的位置，应适当增加颜色，用于区分标题、重点提示、出处块、图示说明、风险提醒、总结或不同模块层级，但必须保持整体简洁、克制、专业，不要花哨。\n2）精读报告在合适的位置，应适当增加支持的小图标或符号，用于辅助读者快速识别信息类型，例如：重点、方法、实验、结果、风险、启发、复现、引用、图示说明、个性化建议等。\n3）颜色和小图标只能起到辅助作用，不能喧宾夺主，不能影响正文可读性，也不能替代严谨表达。\n4）颜色使用应保持少量且统一，优先服务结构层次与阅读导航，不要全篇大面积铺色。\n5）小图标或符号应简洁、学术、易读，可使用常见 Unicode 图标、Emoji 风格简图或平台支持的小型图标，但数量应适中，不要堆砌。\n6）如果平台不支持稳定显示彩色样式或小图标，则应退化为更简洁的文本层次与符号层次，而不是输出失控的花哨格式。\n7）颜色、小图标和可视化图示之间应协调统一：原文图讲解、自绘图、表格、脑图、引用图、时间线、出处块和章节摘要可适当采用一致的视觉提示样式。\n\n可视化数量控制：\n1）不是越多越好，也不是越少越稳。\n2）短报告通常 3 到 5 个可视化即可。\n3）完整精读报告通常 5 到 10 个可视化更合适。\n4）优先保证关键图、关键表、关键公式、关键流程和外部解读图，不要机械凑数量。\n\n最终自检：\n输出前必须检查：\n1）是否出现零图、零表、零公式讲解、零流程图的情况。\n2）自绘图数量是否过少，是否遗漏了适合图解的结构、流程或机制。\n3）是否至少使用过 1 个 Mermaid 图；如果没有，是否明确说明平台不支持 Mermaid 或不适合使用。\n4）ASCII 与 Mermaid 是否根据表达效果合理选择，而不是长期只用一种。\n5）原文关键 Figure/Table/Algorithm/Equation 是否被标注并解释。\n6）如果是 Markdown 报告，引用原文图或截图讲解时是否已尽量插入图片。\n7）外部解读区是否有适当图解。\n8）是否存在整页截图、大段文字截图或无关图片。\n9）每个可视化是否都有讲解和出处。",
    formulaRequirements: "不得自行推导原文未给出的公式。\n原文未定义的变量写“原文未定义”。\n涉及公式时，应解释变量含义、公式作用、输入输出和计算逻辑。\n若原文未提供推导细节，应明确说明“原文未提供”。\n\n公式展示格式：\n1）行内公式使用单个美元符号，例如 $x_i$。\n2）独立公式使用双美元符号单独成段，例如：\n\n$$\nL = L_{ce} + \\lambda L_{reg}\n$$\n\n3）不要把公式放进普通代码块中，除非原文讨论的是代码。\n4）不要把 Markdown 表格、Mermaid 图和复杂 LaTeX 强行混在一起；公式较复杂时应单独成段展示。\n5）不要使用无法稳定渲染的自造格式。\n6）公式编号沿用原文编号，例如“公式 (4)”。如果原文没有编号，可以写“原文未编号公式”。\n\n公式内容规则：\n1）优先将原文公式转写为规范 LaTeX。\n2）不要用整页截图展示公式。\n3）如果公式过于复杂或无法可靠转写，可以使用“公式局部截图”，但只能截取公式本身，不能截整页，并必须给出来源位置。\n4）不得自行补全原文没有给出的推导步骤。\n5）不得把外部推导写进严格无幻觉区。\n6）如需补充推导，必须放入外部解读区，并标注这是外部推导或辅助解释。\n\n公式解释要求：\n1）逐一解释原文明确给出的变量含义。\n2）原文未定义的变量写“原文未定义”。\n3）说明公式用于什么模块、损失、约束、评价指标或计算过程。\n4）说明公式的输入、输出和作用。\n5）每个关键公式必须给出可定位出处，包括材料路径、PDF 页码、章节或公式编号、附近定位短句。"
  };

  const DEFAULT_RULES = BUILTIN_RULES;

  function migrateRules(saved) {
    if (!saved || typeof saved !== 'object') return {};
    if ('userRole' in saved || 'aiRole' in saved || 'infoSources' in saved) return saved;
    const migrated = {};
    if (saved.roleSetting) migrated.aiRole = saved.roleSetting;
    if (saved.lowHallucination) migrated.infoSources = saved.lowHallucination;
    if (saved.externalKnowledge) {
      migrated.externalInterpretation = saved.externalKnowledge;
      migrated.externalInterpretationZone = saved.externalKnowledge;
    }
    if (saved.outputRequirements) migrated.docStyleFormat = saved.outputRequirements;
    return migrated;
  }

  function readSavedRules() {
    const current = SkillUtils.readJSON(RULES_KEY, null);
    if (current && typeof current === 'object') return migrateRules(current);
    const legacy = SkillUtils.readJSON(LEGACY_RULES_KEY, null);
    return migrateRules(legacy);
  }

  const CATEGORY_META = {
    docs: {
      prefix: 'doc',
      label: '文档',
      allowed: DOC_EXT,
      selectorId: 'docMaterialType',
      listId: 'docList',
      inputId: 'docFiles',
      folders: { deep: 'deep_materials/docs', external: 'external_materials/docs' }
    },
    images: {
      prefix: 'image',
      label: '图片',
      allowed: IMAGE_EXT,
      selectorId: 'imageMaterialType',
      listId: 'imageList',
      inputId: 'imageFiles',
      folders: { deep: 'deep_materials/images', external: 'external_materials/images' }
    },
    data: {
      prefix: 'data',
      label: '数据',
      allowed: DATA_EXT,
      selectorId: 'dataMaterialType',
      listId: 'dataList',
      inputId: 'dataFiles',
      folders: { deep: 'deep_materials/data', external: 'external_materials/data' }
    },
    links: {
      prefix: 'link',
      label: '链接',
      allowed: new Set(),
      selectorId: 'linkMaterialType',
      listId: 'linkList',
      folders: { deep: 'deep_materials/links', external: 'external_materials/links' }
    },
    focusFiles: {
      prefix: 'focus',
      label: '关注点附件',
      allowed: FOCUS_FILE_EXT,
      folders: { deep: 'focus_uploads', external: 'focus_uploads' }
    }
  };

  const state = { docs: [], images: [], data: [], links: [], focusFiles: [], focusEntries: [], focusEntriesReady: false };
  let editingFocusId = '';
  let focusSelection = { type: 'none', id: '' };

  function element(id) { return document.getElementById(id); }

  function makeId(prefix) {
    return `${prefix}_${Date.now()}_${Math.random().toString(16).slice(2)}`;
  }

  function getDefaultRules() {
    return { ...BUILTIN_RULES, ...readSavedRules() };
  }

  function getBuiltInRules() {
    return { ...BUILTIN_RULES };
  }

  function getCustomRules() {
    return getDefaultRules();
  }

  function hasCustomRules() {
    const saved = SkillUtils.readJSON(RULES_KEY, null) || SkillUtils.readJSON(LEGACY_RULES_KEY, null);
    return saved && Object.keys(saved).length > 0;
  }

  function getRuleMode() {
    const checked = document.querySelector('input[name="ruleMode"]:checked');
    return checked ? checked.value : 'default';
  }

  function getActiveRules() {
    return getDefaultRules();
  }

  function normalizeFocusText(text) {
    return String(text || '').replace(/\r\n/g, '\n').trim();
  }

  function normalizeFocusEntries(entries) {
    return (Array.isArray(entries) ? entries : [])
      .map((item, index) => {
        const text = normalizeFocusText(item && item.text);
        if (!text) return null;
        return {
          id: item.id || makeId('focus'),
          serial: index + 1,
          text,
          title: item.title || `关注点 ${index + 1}`,
          source: item.source || 'input',
          createdAt: item.createdAt || new Date().toISOString(),
          updatedAt: item.updatedAt || ''
        };
      })
      .filter(Boolean)
      .map((item, index) => ({ ...item, serial: index + 1 }));
  }

  function focusStorageEnabled() {
    return !!element('rulesForm');
  }

  function initializeFocusEntries() {
    if (state.focusEntriesReady) return;
    state.focusEntriesReady = true;

    if (!focusStorageEnabled()) {
      state.focusEntries = [];
      return;
    }

    const entries = SkillUtils.readJSON(FOCUS_LIBRARY_KEY, null);
    if (Array.isArray(entries)) {
      state.focusEntries = normalizeFocusEntries(entries);
      return;
    }

    const oldItems = SkillUtils.readJSON(OLD_FOCUS_KEY, []);
    if (Array.isArray(oldItems) && oldItems.length) {
      state.focusEntries = normalizeFocusEntries(oldItems.map((text, index) => ({
        id: `focus_${Date.now()}_${index}`,
        text: String(text || '').trim(),
        title: '历史关注点',
        source: 'migrated',
        createdAt: new Date().toISOString()
      })));
      SkillUtils.writeJSON(FOCUS_LIBRARY_KEY, state.focusEntries);
      return;
    }

    state.focusEntries = [];
  }

  function loadFocusEntries() {
    initializeFocusEntries();
    return normalizeFocusEntries(state.focusEntries || []);
  }

  function saveFocusEntries(entries) {
    const normalized = normalizeFocusEntries(entries);
    state.focusEntries = normalized;
    state.focusEntriesReady = true;
    return normalized;
  }

  function commitFocusEntries() {
    const normalized = normalizeFocusEntries(state.focusEntries || []);
    state.focusEntries = normalized;
    state.focusEntriesReady = true;
    SkillUtils.writeJSON(FOCUS_LIBRARY_KEY, normalized);
    return normalized;
  }

  function replaceFocusEntriesFromText(text) {
    const raw = normalizeFocusText(text);
    if (!raw) {
      saveFocusEntries([]);
      return [];
    }
    const normalized = raw
      .replace(/\r\n/g, '\n')
      .replace(/^\s*\d+[\.\、]\s+/gm, '\n@@FOCUS@@')
      .split('\n@@FOCUS@@')
      .map((part) => part.trim())
      .filter(Boolean);
    const parts = normalized.length ? normalized : raw.split(/\n{2,}/).map((part) => part.trim()).filter(Boolean);
    return saveFocusEntries(parts.map((part, index) => ({
      id: makeId('focus'),
      serial: index + 1,
      text: part,
      title: `关注点 ${index + 1}`,
      source: 'rules',
      createdAt: new Date().toISOString()
    })));
  }

  function getFocusTextForRules() {
    const entries = loadFocusEntries();
    return entries.map((entry, index) => `${index + 1}. ${entry.text}`).join('\n\n');
  }

  function nextFocusSerial(entries) {
    return normalizeFocusEntries(entries).length + 1;
  }

  function focusPreview(text, limit = 70) {
    const clean = normalizeFocusText(text).replace(/\s+/g, ' ');
    return clean.length > limit ? `${clean.slice(0, limit)}...` : clean;
  }

  function clearSelection() {
    editingFocusId = '';
    focusSelection = { type: 'none', id: '' };
  }

  function selectTextEntry(entry) {
    editingFocusId = entry.id;
    focusSelection = { type: 'text', id: entry.id };
    const box = element('focusText');
    if (box) box.value = entry.text;
    renderFocusList();
    updateFocusToolbarState();
    if (focusStorageEnabled()) {
      SkillUtils.writeJSON(DEFAULT_FOCUS_FILES_KEY, serializeFocusFiles(state.focusFiles));
    }
    if (box) box.focus({ preventScroll: false });
  }

  function selectFocusFile(item) {
    editingFocusId = '';
    focusSelection = { type: 'file', id: item.id };
    const box = element('focusText');
    if (box) box.value = '';
    renderFocusList();
    updateFocusToolbarState();
    if (focusStorageEnabled()) {
      SkillUtils.writeJSON(DEFAULT_FOCUS_FILES_KEY, serializeFocusFiles(state.focusFiles));
    }
  }

  function updateFocusToolbarState() {
    const selectedFile = focusSelection.type === 'file';
    const selectedText = focusSelection.type === 'text';
    const save = element('btnSaveFocus');
    const update = element('btnUpdateFocus');
    const clear = element('btnClearFocus');

    if (save) {
      save.disabled = selectedFile;
      save.title = selectedFile ? '当前选中的是非文本附件。若要新增文本，请先在输入框中输入内容，系统会自动切换为文本新增。' : (focusStorageEnabled() ? '将输入框内容新增到默认关注点，保存配置后成为默认配置。' : '将输入框内容新增到本次关注点，仅本次生成使用。');
    }
    if (update) {
      update.disabled = selectedFile || !selectedText;
      update.title = selectedFile ? '当前选中的是非文本附件，不能修改文本。' : selectedText ? '修改当前选中的文本关注点。' : '请先选中一条文本关注点。';
    }
    if (clear) {
      clear.disabled = selectedFile;
      clear.title = selectedFile ? '当前选中的是非文本附件，不能清空文本。' : '清空上方输入框。';
    }
  }

  function appendFocusEntry(text, options = {}) {
    const clean = normalizeFocusText(text);
    if (!clean) return { ok: false, message: '请先填写重点关注内容。' };
    const entries = loadFocusEntries();
    if (entries.some((item) => normalizeFocusText(item.text) === clean)) {
      return { ok: false, message: '这条重点关注已经保存过。' };
    }
    const serial = nextFocusSerial(entries);
    const entry = {
      id: makeId('focus'),
      serial,
      text: clean,
      title: options.title || `关注点 ${serial}`,
      source: options.source || 'input',
      createdAt: new Date().toISOString()
    };
    const saved = saveFocusEntries([...entries, entry]);
    const selected = saved.find((item) => item.id === entry.id) || entry;
    editingFocusId = selected.id;
    focusSelection = { type: 'text', id: selected.id };
    renderFocusList();
    updateFocusToolbarState();
    if (focusStorageEnabled()) {
      SkillUtils.writeJSON(DEFAULT_FOCUS_FILES_KEY, serializeFocusFiles(state.focusFiles));
    }
    return { ok: true, message: focusStorageEnabled() ? `已添加为第 ${selected.serial} 条默认关注点；点击“保存配置”后会成为默认配置。` : `已添加为第 ${selected.serial} 条本次关注点，仅本次生成使用。` };
  }

  function updateFocusEntry(id, text) {
    const clean = normalizeFocusText(text);
    if (!clean) return { ok: false, message: '请先填写重点关注内容。' };
    const entries = loadFocusEntries();
    const index = entries.findIndex((item) => item.id === id);
    if (index < 0) return { ok: false, message: '请先点击一条文本关注点，再进行修改。' };
    entries[index] = { ...entries[index], text: clean, updatedAt: new Date().toISOString() };
    const saved = saveFocusEntries(entries);
    const updated = saved.find((item) => item.id === id) || entries[index];
    editingFocusId = id;
    focusSelection = { type: 'text', id };
    renderFocusList();
    updateFocusToolbarState();
    if (focusStorageEnabled()) {
      SkillUtils.writeJSON(DEFAULT_FOCUS_FILES_KEY, serializeFocusFiles(state.focusFiles));
    }
    return { ok: true, message: focusStorageEnabled() ? `已修改第 ${updated.serial} 条默认关注点；点击“保存配置”后会成为默认配置。` : `已修改第 ${updated.serial} 条本次关注点。` };
  }

  function deleteFocusEntry(id) {
    const entries = loadFocusEntries();
    const index = entries.findIndex((item) => item.id === id);
    if (index < 0) return { ok: false, message: '没有找到要删除的重点关注。' };
    const removed = entries[index];
    entries.splice(index, 1);
    saveFocusEntries(entries);
    if (editingFocusId === id || focusSelection.id === id) {
      clearSelection();
      const box = element('focusText');
      if (box) box.value = '';
    }
    renderFocusList();
    updateFocusToolbarState();
    if (focusStorageEnabled()) {
      SkillUtils.writeJSON(DEFAULT_FOCUS_FILES_KEY, serializeFocusFiles(state.focusFiles));
    }
    return { ok: true, message: focusStorageEnabled() ? `已删除第 ${removed.serial} 条默认关注点；点击“保存配置”后会同步为默认配置。` : `已删除第 ${removed.serial} 条本次关注点。` };
  }

  function addFocusItem() {
    const text = element('focusText') ? element('focusText').value : '';
    if (focusSelection.type === 'file' && normalizeFocusText(text)) clearSelection();
    return appendFocusEntry(text, { source: 'input', title: '手动输入' });
  }

  function updateFocusItem() {
    if (focusSelection.type === 'file') return { ok: false, message: '当前选中的是非文本附件，不能修改文本内容。' };
    if (!editingFocusId) return { ok: false, message: '请先在“常用关注点”中点击一条文本内容。' };
    return updateFocusEntry(editingFocusId, element('focusText') ? element('focusText').value : '');
  }

  function clearFocusInput() {
    if (focusSelection.type === 'file') return { ok: false, message: '当前选中的是非文本附件，不能清空文本输入框。' };
    clearSelection();
    const box = element('focusText');
    if (box) box.value = '';
    renderFocusList();
    updateFocusToolbarState();
    if (focusStorageEnabled()) {
      SkillUtils.writeJSON(DEFAULT_FOCUS_FILES_KEY, serializeFocusFiles(state.focusFiles));
    }
    return { ok: true, message: focusStorageEnabled() ? '输入框已清空，默认关注点列表不会被删除。' : '输入框已清空，本次关注点列表不会被删除。' };
  }

  function persistFocusIfNeeded() {
    const box = element('focusText');
    const text = box ? normalizeFocusText(box.value) : '';
    if (!text) return { ok: true, message: '无需保存空白重点关注。' };
    if (focusSelection.type === 'file') {
      clearSelection();
      return appendFocusEntry(text, { source: 'input', title: '手动输入' });
    }
    if (editingFocusId) return updateFocusEntry(editingFocusId, text);
    return appendFocusEntry(text, { source: 'input', title: '手动输入' });
  }

  function compiledFocusText() {
    const entries = loadFocusEntries();
    const lines = [];
    entries.forEach((entry) => lines.push(`${entry.serial}. ${entry.text}`));
    if (state.focusFiles.length) {
      lines.push('', '关注点附件：');
      state.focusFiles.forEach((item, index) => lines.push(`- 附件 ${index + 1}: ${item.file.name}（见 ${item.storedPath}）`));
    }
    return lines.join('\n\n').trim();
  }

  function readForm() {
    const rules = getActiveRules();
    return {
      skillName: element('skillName').value,
      focusText: compiledFocusText(),
      ruleMode: getRuleMode(),
      userRole: rules.userRole,
      aiRole: rules.aiRole,
      infoSources: rules.infoSources,
      referencesLimit: rules.referencesLimit,
      externalInterpretation: rules.externalInterpretation,
      docStyleFormat: rules.docStyleFormat,
      sectionPrinciple: rules.sectionPrinciple,
      strictNoHallucinationZone: rules.strictNoHallucinationZone,
      externalInterpretationZone: rules.externalInterpretationZone,
      visualizationPrinciple: rules.visualizationPrinciple,
      formulaRequirements: rules.formulaRequirements
    };
  }

  function validateRequired(formData) {
    const missing = [];
    if (!String(formData.skillName || '').trim()) missing.push('技能名称');
    const hasDeepDocs = state.docs.some((item) => (item.scope || 'deep') === 'deep');
    if (!hasDeepDocs) missing.push('精读文档材料');
    return missing;
  }

  function getScope(category) {
    const meta = CATEGORY_META[category];
    const selector = meta && meta.selectorId ? element(meta.selectorId) : null;
    return selector && selector.value === 'external' ? 'external' : 'deep';
  }

  function scopeLabel(scope) {
    return scope === 'external' ? '外部材料' : '精读材料';
  }

  function scopedTitle(category, scope) {
    const map = {
      docs: { deep: '精读文档材料', external: '外部文档材料' },
      images: { deep: '精读图片材料', external: '外部图片材料' },
      data: { deep: '精读数据材料', external: '外部数据材料' },
      links: { deep: '精读链接材料', external: '外部链接材料' }
    };
    return (map[category] && map[category][scope]) || scopeLabel(scope);
  }

  function validateFileForCategory(file, category) {
    const meta = CATEGORY_META[category];
    const ext = SkillUtils.getExt(file.name);
    if (!ext) return `${file.name} 缺少扩展名，无法判断是否属于${meta.label}材料。`;
    if (!meta.allowed.has(ext)) return `${file.name} 不是有效${meta.label}文件，请不要混放。`;
    if (category === 'images' && file.type && !file.type.startsWith('image/') && ext !== 'svg') return `${file.name} 的 MIME 类型不是图片。`;
    return '';
  }

  function buildStoredName(file, category, index, scope) {
    const meta = CATEGORY_META[category];
    const safe = SkillUtils.sanitizeFileName(file.name);
    const folder = meta.folders[scope || 'deep'];
    return `${folder}/${safe}`;
  }

  function refreshStoredPaths(category) {
    if (category === 'focusFiles') {
      state.focusFiles.forEach((item, index) => {
        if (!item.id) item.id = makeId('focus_file');
        item.storedPath = `focus_uploads/${SkillUtils.sanitizeFileName(item.file.name)}`;
      });
      return;
    }
    state[category].forEach((item, index) => {
      item.storedPath = buildStoredName(item.file, category, index, item.scope || 'deep');
    });
  }

  function addFiles(fileList, category) {
    const errors = [];
    const incoming = Array.from(fileList || []);
    const scope = getScope(category);
    incoming.forEach((file) => {
      const error = validateFileForCategory(file, category);
      if (error) { errors.push(error); return; }
      const duplicated = state[category].some((item) => item.file.name === file.name && item.file.size === file.size && item.file.lastModified === file.lastModified && item.scope === scope);
      if (duplicated) { errors.push(`${file.name} 已经添加过。`); return; }
      state[category].push({ file, scope, storedPath: '' });
    });
    refreshStoredPaths(category);
    renderFileList(category);
    return errors;
  }

  function normalizeLink(text) {
    return String(text || '').trim();
  }

  function isProbablyLink(text) {
    const value = normalizeLink(text);
    if (!value) return false;
    return /^(https?:\/\/|doi:|arxiv:|www\.)/i.test(value) || /^[^\s]+\.[^\s]{2,}/.test(value);
  }

  function addLinks(rawText) {
    const scope = getScope('links');
    const lines = String(rawText || '').split(/\n+/).map((line) => line.trim()).filter(Boolean);
    if (!lines.length) return { ok: false, added: 0, errors: ['请先输入链接材料。'] };
    const errors = [];
    let added = 0;
    lines.forEach((line) => {
      if (!isProbablyLink(line)) {
        errors.push(`${line} 看起来不像有效链接 / DOI / arXiv 编号。`);
        return;
      }
      const duplicated = state.links.some((item) => item.value === line && item.scope === scope);
      if (duplicated) {
        errors.push(`${line} 已经添加过。`);
        return;
      }
      state.links.push({ id: makeId('link'), scope, value: line, title: scopedTitle('links', scope), createdAt: new Date().toISOString() });
      added += 1;
    });
    renderLinkList();
    updateUploadStats();
    return { ok: added > 0 && !errors.length, added, errors };
  }

  function removeLink(index) {
    state.links.splice(index, 1);
    renderLinkList();
    updateUploadStats();
  }

  function removeFile(category, index) {
    state[category].splice(index, 1);
    refreshStoredPaths(category);
    renderFileList(category);
  }

  function isFocusTextFile(file) {
    const ext = SkillUtils.getExt(file.name);
    return FOCUS_TEXT_EXT.has(ext) || (file.type && file.type.startsWith('text/'));
  }

  async function addFocusFiles(fileList) {
    const errors = [];
    let textCount = 0;
    let fileCount = 0;
    const incoming = Array.from(fileList || []);
    for (const file of incoming) {
      const ext = SkillUtils.getExt(file.name);
      if (!ext || !FOCUS_FILE_EXT.has(ext)) {
        errors.push(`${file.name} 不是支持的关注点文件。`);
        continue;
      }
      if (isFocusTextFile(file)) {
        try {
          const text = await file.text();
          const result = appendFocusEntry(text, { source: 'file', title: file.name });
          if (result.ok) textCount += 1;
          else errors.push(`${file.name}: ${result.message}`);
        } catch (_) {
          errors.push(`${file.name} 读取失败，未能融合为文本关注点。`);
        }
        continue;
      }
      const duplicated = state.focusFiles.some((item) => item.file.name === file.name && item.file.size === file.size && item.file.lastModified === file.lastModified);
      if (duplicated) { errors.push(`${file.name} 已经添加过。`); continue; }
      const item = { id: makeId('focus_file'), file, storedPath: '' };
      state.focusFiles.push(item);
      focusSelection = { type: 'file', id: item.id };
      editingFocusId = '';
      fileCount += 1;
    }
    refreshStoredPaths('focusFiles');
    if (focusStorageEnabled()) {
      SkillUtils.writeJSON(DEFAULT_FOCUS_FILES_KEY, serializeFocusFiles(state.focusFiles));
    }
    renderFocusList();
    updateFocusToolbarState();
    if (focusStorageEnabled()) {
      SkillUtils.writeJSON(DEFAULT_FOCUS_FILES_KEY, serializeFocusFiles(state.focusFiles));
    }
    return { errors, textCount, fileCount };
  }

  function removeFocusFile(index) {
    const removed = state.focusFiles[index];
    state.focusFiles.splice(index, 1);
    refreshStoredPaths('focusFiles');
    if (focusStorageEnabled()) {
      SkillUtils.writeJSON(DEFAULT_FOCUS_FILES_KEY, serializeFocusFiles(state.focusFiles));
    }
    if (removed && focusSelection.type === 'file' && focusSelection.id === removed.id) {
      clearSelection();
      const box = element('focusText');
      if (box) box.value = '';
    }
    renderFocusList();
    updateFocusToolbarState();
    if (focusStorageEnabled()) {
      SkillUtils.writeJSON(DEFAULT_FOCUS_FILES_KEY, serializeFocusFiles(state.focusFiles));
    }
  }

  function updateUploadStats() {
    const imageCount = element('imageCount');
    const docCount = element('docCount');
    const dataCount = element('dataCount');
    const linkCount = element('linkCount');
    const totalSize = element('totalSize');
    const totalBytes = ['images', 'docs', 'data'].reduce((sum, key) => sum + state[key].reduce((s, item) => s + item.file.size, 0), 0);
    if (imageCount) imageCount.textContent = String(state.images.length);
    if (docCount) docCount.textContent = String(state.docs.length);
    if (dataCount) dataCount.textContent = String(state.data.length);
    if (linkCount) linkCount.textContent = String(state.links.length);
    if (totalSize) {
      const readableSize = SkillUtils.formatBytes(totalBytes);
      totalSize.textContent = readableSize;
      totalSize.title = readableSize;
      totalSize.setAttribute('aria-label', `总大小：${readableSize}`);
    }
  }

  function renderFileList(category) {
    const meta = CATEGORY_META[category];
    const list = element(meta.listId);
    if (!list) return;
    const scope = getScope(category);
    const scopedItems = state[category]
      .map((item, index) => ({ item, index }))
      .filter((entry) => (entry.item.scope || 'deep') === scope);

    list.innerHTML = '';
    if (!scopedItems.length) {
      const empty = document.createElement('li');
      empty.className = 'file-empty';
      empty.textContent = `尚未选择${scopedTitle(category, scope)}`;
      list.appendChild(empty);
      updateUploadStats();
      return;
    }

    scopedItems.forEach(({ item, index }) => {
      const li = document.createElement('li');
      li.className = 'file-item';

      const detail = document.createElement('div');
      const name = document.createElement('div');
      const metaLine = document.createElement('div');
      name.className = 'file-name';
      metaLine.className = 'file-meta';
      name.title = item.file.name;
      name.textContent = item.file.name;
      metaLine.textContent = `${SkillUtils.formatBytes(item.file.size)} · ${SkillUtils.getExt(item.file.name).toUpperCase() || '未知类型'}`;
      detail.appendChild(name);
      detail.appendChild(metaLine);

      const button = document.createElement('button');
      button.className = 'file-remove';
      button.type = 'button';
      button.setAttribute('aria-label', `移除 ${item.file.name}`);
      button.textContent = '×';
      button.addEventListener('click', () => removeFile(category, index));

      li.appendChild(detail);
      li.appendChild(button);
      list.appendChild(li);
    });
    updateUploadStats();
  }

  function renderLinkList() {
    const list = element('linkList');
    if (!list) return;
    const scope = getScope('links');
    const scopedLinks = state.links
      .map((item, index) => ({ item, index }))
      .filter((entry) => (entry.item.scope || 'deep') === scope);

    list.innerHTML = '';
    if (!scopedLinks.length) {
      const empty = document.createElement('li');
      empty.className = 'file-empty';
      empty.textContent = `尚未添加${scopedTitle('links', scope)}`;
      list.appendChild(empty);
      return;
    }

    scopedLinks.forEach(({ item, index }) => {
      const li = document.createElement('li');
      li.className = 'file-item link-item';

      const detail = document.createElement('div');
      const name = document.createElement('div');
      const metaLine = document.createElement('div');
      name.className = 'file-name';
      metaLine.className = 'file-meta';
      name.title = item.value;
      name.textContent = item.value;
      metaLine.textContent = item.scope === 'external' ? '外部链接材料' : '精读链接材料';
      detail.appendChild(name);
      detail.appendChild(metaLine);

      const button = document.createElement('button');
      button.className = 'file-remove';
      button.type = 'button';
      button.setAttribute('aria-label', `移除链接 ${item.value}`);
      button.textContent = '×';
      button.addEventListener('click', () => removeLink(index));

      li.appendChild(detail);
      li.appendChild(button);
      list.appendChild(li);
    });
  }

  function renderFocusList() {
    const list = element('focusList');
    if (!list) return;
    list.innerHTML = '';
    const entries = loadFocusEntries();
    if (!entries.length && !state.focusFiles.length) {
      const empty = document.createElement('li');
      empty.className = 'focus-empty';
      empty.textContent = focusStorageEnabled() ? '暂无默认关注点。' : '暂无本次关注点。';
      list.appendChild(empty);
      updateFocusToolbarState();
      return;
    }

    entries.forEach((entry, index) => {
      const li = document.createElement('li');
      const selected = focusSelection.type === 'text' && focusSelection.id === entry.id;
      li.className = `focus-item focus-item--text${selected ? ' is-selected is-editing' : ''}`;
      li.setAttribute('aria-selected', selected ? 'true' : 'false');

      const detail = document.createElement('button');
      detail.type = 'button';
      detail.className = 'focus-item__detail';
      detail.title = '点击后在上方文本框中查看或修改';
      detail.addEventListener('click', () => selectTextEntry(entry));

      const serial = document.createElement('span');
      serial.className = 'focus-serial';
      serial.textContent = String(index + 1).padStart(2, '0');

      const body = document.createElement('span');
      body.className = 'focus-item__body';
      const title = document.createElement('strong');
      title.textContent = focusPreview(entry.text);
      const meta = document.createElement('small');
      meta.textContent = entry.source === 'file' ? `文本关注点 · 来自 ${entry.title || '上传文件'}` : (focusStorageEnabled() ? '默认关注点 · 保存配置后成为默认配置' : '本次关注点 · 仅本次生成使用');
      body.appendChild(title);
      body.appendChild(meta);

      detail.appendChild(serial);
      detail.appendChild(body);

      const del = document.createElement('button');
      del.className = 'file-remove';
      del.type = 'button';
      del.setAttribute('aria-label', `删除第 ${entry.serial} 条关注点`);
      del.textContent = '×';
      del.addEventListener('click', () => deleteFocusEntry(entry.id));

      li.appendChild(detail);
      li.appendChild(del);
      list.appendChild(li);
    });

    state.focusFiles.forEach((item, index) => {
      if (!item.id) item.id = makeId('focus_file');
      const displayIndex = entries.length + index + 1;
      const selected = focusSelection.type === 'file' && focusSelection.id === item.id;
      const li = document.createElement('li');
      li.className = `focus-item focus-item--file${selected ? ' is-selected is-selected-file' : ''}`;
      li.setAttribute('aria-selected', selected ? 'true' : 'false');

      const detail = document.createElement('button');
      detail.type = 'button';
      detail.className = 'focus-item__detail';
      detail.title = '非文本附件：只支持新增和删除';
      detail.addEventListener('click', () => selectFocusFile(item));

      const serial = document.createElement('span');
      serial.className = 'focus-serial focus-serial--file';
      serial.textContent = String(displayIndex).padStart(2, '0');

      const body = document.createElement('span');
      body.className = 'focus-item__body';
      const title = document.createElement('strong');
      title.textContent = fileItemName(item);
      const meta = document.createElement('small');
      meta.textContent = `${SkillUtils.formatBytes(fileItemSize(item))} · ${SkillUtils.getExt(fileItemName(item)).toUpperCase() || '未知类型'} · 非文本附件`;
      body.appendChild(title);
      body.appendChild(meta);

      detail.appendChild(serial);
      detail.appendChild(body);

      const del = document.createElement('button');
      del.className = 'file-remove';
      del.type = 'button';
      del.setAttribute('aria-label', `删除第 ${displayIndex} 条关注点附件 ${fileItemName(item)}`);
      del.textContent = '×';
      del.addEventListener('click', () => removeFocusFile(index));

      li.appendChild(detail);
      li.appendChild(del);
      list.appendChild(li);
    });
    updateFocusToolbarState();
  }

  function initFocusLibrary() {
    renderFocusList();
    const box = element('focusText');
    if (box) {
      box.value = '';
      box.addEventListener('input', () => {
        if (focusSelection.type === 'file' && normalizeFocusText(box.value)) {
          clearSelection();
          renderFocusList();
        }
        updateFocusToolbarState();
      });
    }
    updateFocusToolbarState();
  }

  function refreshRuleStatus() {
    /* 自定义规则已改为单按钮入口；主页始终使用当前本地默认配置。 */
  }

  function initRuleMode() {
    const btn = element('btnOpenCustomRules');
    if (btn) {
      btn.addEventListener('click', () => {
        persistFocusIfNeeded();
        saveCurrentFocusFiles();
        window.location.href = 'rules.html';
      });
    }
    refreshRuleStatus();
  }

  function resetAll() {
    element('skillForm').reset();
    state.docs = [];
    state.images = [];
    state.data = [];
    state.links = [];
    state.focusFiles = [];
    state.focusEntries = [];
    state.effectiveFocusFiles = [];
    state.focusEntriesReady = true;
    if (!focusStorageEnabled()) clearSessionFocusState();
    clearSelection();
    const box = element('focusText');
    const linkInput = element('linkInput');
    if (box) box.value = '';
    if (linkInput) linkInput.value = '';
    renderFileList('docs');
    renderFileList('images');
    renderFileList('data');
    renderLinkList();
    renderFocusList();
    refreshRuleStatus();
    updateFocusToolbarState();
    updateUploadStats();
  }

  function updateDocRequiredMarker() {
    const marker = element('docRequiredStar');
    const selector = element('docMaterialType');
    if (!marker || !selector) return;
    marker.hidden = selector.value === 'external';
  }

  function initMaterialControls() {
    renderFileList('docs');
    renderFileList('images');
    renderFileList('data');
    renderLinkList();
    updateUploadStats();
    updateDocRequiredMarker();
  }


  function initMaterialSelectors() {
    ['docs', 'images', 'data'].forEach((category) => {
      const meta = CATEGORY_META[category];
      const selector = meta && meta.selectorId ? element(meta.selectorId) : null;
      if (selector) {
        selector.addEventListener('change', () => {
          renderFileList(category);
          if (category === 'docs') updateDocRequiredMarker();
        });
      }
    });
    const linkSelector = element('linkMaterialType');
    if (linkSelector) linkSelector.addEventListener('change', renderLinkList);
    updateDocRequiredMarker();
  }

    const BUILTIN_FOCUS_ENTRIES = [
      {
          "id": "built_in_focus_computer_paper",
          "serial": 1,
          "text": "计算机相关论文默认的章节安排（共15章）\n\n1. 基本信息\n核心关注点：论文身份与领域定位\n精读时要问：题目、作者、机构、年份、会议/期刊是什么？属于哪个方向？\n记录建议：记录论文来源、关键词、任务类型、应用场景。\n\n2. 问题定义\n核心关注点：研究对象与目标\n精读时要问：这篇论文到底想解决什么问题？输入是什么？输出是什么？评价目标是什么？\n记录建议：用一句话概括：在什么场景下，为了解决什么任务，优化什么指标。\n\n3. 研究动机\n核心关注点：现有方法的不足\n精读时要问：作者认为前人方法哪里不够好？是效果差、效率低、泛化差、数据依赖强，还是理论解释不足？\n记录建议：区分“真实问题”和“作者为了引出方法而强调的问题”。\n\n4. 核心贡献\n核心关注点：新意与价值\n精读时要问：作者提出了什么新东西？新模型、新算法、新损失、新数据集、新训练策略，还是新分析视角？\n记录建议：不要只抄作者贡献点，要判断每个贡献是否被实验支撑。\n\n5. 方法框架\n核心关注点：技术路线与整体结构\n精读时要问：方法由哪些模块组成？数据如何流动？关键计算过程是什么？\n记录建议：画出模型架构图或流程图，重点标明输入、输出、模块关系。\n\n6. 关键公式/算法\n核心关注点：方法的数学本质\n精读时要问：核心公式、损失函数、优化目标、算法步骤是什么？每个变量代表什么？\n记录建议：逐项解释变量含义，避免只看公式形式不理解作用。\n\n7. 数据与任务设置\n核心关注点：数据来源与实验任务\n精读时要问：使用了哪些数据集？训练、验证、测试如何划分？任务设定是否合理？\n记录建议：关注数据规模、类别分布、标注方式、是否存在数据泄漏。\n\n8. 实验设计\n核心关注点：对比与验证逻辑\n精读时要问：Baseline 是否公平？评价指标是否合适？实验是否能证明作者的主张？\n记录建议：重点看：主实验、消融实验、泛化实验、鲁棒性实验。\n\n9. 结果分析\n核心关注点：性能提升是否可信\n精读时要问：提升有多大？是否稳定？是否只在个别数据集或指标上有效？\n记录建议：不只看最高分，还要看方差、统计显著性、失败案例和可视化分析。\n\n10. 消融与机制验证\n核心关注点：哪个部分真正有效\n精读时要问：去掉某个模块后性能如何变化？每个设计是否都有必要？\n记录建议：判断方法是“结构真的有效”，还是“参数量、数据量、训练技巧带来的提升”。\n\n11. 复杂度与可复现性\n核心关注点：实际使用成本\n精读时要问：参数量、计算量、显存、训练时间、推理速度、硬件要求是多少？代码是否开源？\n记录建议：记录代码地址、核心超参数、训练细节、环境依赖。\n\n12. 局限性与风险\n核心关注点：方法边界\n精读时要问：方法在哪些场景下可能失败？是否依赖特定数据、任务、硬件或假设？\n记录建议：主动总结作者承认的局限，以及自己发现的潜在问题。\n\n13. 迁移与启发\n核心关注点：对自己研究的价值\n精读时要问：这个方法、思想、实验设计能否迁移到我的课题？\n记录建议：记录可借鉴的技术点、不可直接迁移的限制、后续改进方向。\n\n14. 个性化建议\n核心关注点：根据当前的文章解读结果，结合用户角色，给出进一步的个性化研究建议、为用户试设计新的idea、并规划详细的工作流。\n\n15. 前沿研究\n核心关注点：针对论文涉及到的研究内容，生成前沿研究分析。",
          "title": "计算机相关论文默认章节安排",
          "source": "built-in",
          "createdAt": "built-in",
          "updatedAt": ""
      },
      {
          "id": "built_in_focus_medical_paper",
          "serial": 2,
          "text": "人与动物共有医学相关论文默认的章节安排（共18章）\n\n1. 基本信息\n核心关注点：论文身份与研究类型\n精读时要问：题目、作者、机构、年份、期刊是什么？属于临床研究、动物实验、流行病学、诊断研究、机制研究，还是综述？\n记录建议：先判断研究类型，因为不同论文的证据强度不同。\n\n2. 研究对象\n核心关注点：人、动物、环境三方\n精读时要问：研究对象是人、动物、病原体、环境样本，还是多者结合？\n记录建议：记录人群特征、动物种属/品系、样本来源、环境场景。\n\n3. 研究问题\n核心关注点：医学问题定义\n精读时要问：论文想解决什么问题？诊断、治疗、预防、传播、机制、风险因素，还是模型验证？\n记录建议：用一句话概括：在什么对象中，研究什么因素，对什么结局产生什么影响。\n\n4. 研究背景与意义\n核心关注点：临床、兽医与公共卫生价值\n精读时要问：为什么这个问题重要？是否涉及发病率、死亡率、传播风险、动物福利、食品安全、抗菌药耐药或公共卫生风险？\n记录建议：区分“作者声称的重要性”和“数据实际支持的重要性”。\n\n5. 研究设计\n核心关注点：证据强度\n精读时要问：是随机试验、队列研究、病例对照、横断面研究、动物实验、体外实验、监测研究，还是系统综述？\n记录建议：判断该设计能否支持因果结论，不要把相关性读成因果性。\n\n6. 样本与分组\n核心关注点：样本可靠性\n精读时要问：样本量是否足够？纳入/排除标准是否清楚？分组是否合理？是否随机、盲法、设对照？\n记录建议：动物研究尤其要记录：种属、品系、年龄、性别、健康状态、饲养条件、随机化、盲法。\n\n7. 暴露/干预\n核心关注点：关键变量定义\n精读时要问：暴露因素或干预措施是什么？如感染、药物、疫苗、饲养方式、接触史、环境污染、抗生素使用等。\n记录建议：记录剂量、途径、频率、持续时间、暴露测量方法。\n\n8. 结局指标\n核心关注点：结果是否有医学意义\n精读时要问：作者测量了什么结果？死亡率、感染率、病原载量、抗体水平、临床评分、病理变化、传播率等。\n记录建议：区分替代指标和真正的临床/公共卫生结局。\n\n9. 检测与诊断方法\n核心关注点：测量可信度\n精读时要问：使用了什么检测方法？PCR、培养、血清学、测序、影像、病理、问卷或临床诊断标准？\n记录建议：关注灵敏度、特异度、金标准、采样时间、样本保存与运输。\n\n10. 统计分析\n核心关注点：结果是否稳健\n精读时要问：是否报告效应量、置信区间、P 值？是否处理混杂因素、缺失数据、重复测量和群体聚集效应？\n记录建议：不只看 P 值，更要看效应大小、置信区间和实际医学意义。\n\n11. 偏倚与混杂\n核心关注点：可信性风险\n精读时要问：是否存在选择偏倚、检测偏倚、回忆偏倚、实验者偏倚、批次效应或未控制的混杂因素？\n记录建议：主动问：结果有没有可能由样本来源、分组不均或检测方法导致？\n\n12. 机制解释\n核心关注点：生物学合理性\n精读时要问：作者是否解释病原、宿主、免疫、组织病理、跨种传播或药物作用机制？\n记录建议：把“实验证据支持的机制”和“作者推测的机制”分开记录。\n\n13. 跨种转化价值\n核心关注点：从动物到人，或从人到动物\n精读时要问：动物结果能否外推到人？人类研究能否反哺动物医学？种属差异是否被讨论？\n记录建议：重点写清楚：能转化什么，不能转化什么，外推条件是什么。\n\n14. 伦理与生物安全\n核心关注点：合规性\n精读时要问：是否说明伦理审批、知情同意、动物福利、3R 原则、生物安全等级和样本处理规范？\n记录建议：对动物实验、病原研究、人兽共患病研究，这是核心内容。\n\n15. 结论与局限\n核心关注点：结论边界\n精读时要问：作者的结论是否超过数据范围？承认了哪些局限？还有哪些未讨论的问题？\n记录建议：将局限分为：设计局限、样本局限、测量局限、统计局限、外推局限。\n\n16. 实践价值\n核心关注点：临床、兽医、公共卫生应用\n精读时要问：研究能否改变诊断、治疗、预防、监测、饲养管理或政策制定？\n记录建议：最后判断：这篇论文对医学实践、科研设计或公共卫生决策有什么价值。\n\n17. 个性化建议\n核心关注点：根据当前的文章解读结果，结合用户角色，给出进一步的个性化研究建议、为用户试设计新的idea、并规划详细的工作流。\n\n18. 前沿研究\n核心关注点：针对论文涉及到的研究内容，生成前沿研究分析。",
          "title": "人与动物共有医学相关论文默认章节安排",
          "source": "built-in",
          "createdAt": "built-in",
          "updatedAt": ""
      },
      {
          "id": "built_in_focus_other_domain_paper",
          "serial": 3,
          "text": "其他领域相关论文默认的章节安排如下（共16章）\n\n1. 基本信息\n核心关注点：论文身份与学科定位\n精读时要问：题目、作者、机构、年份、期刊/会议/出版源是什么？属于哪个学科、方向或问题域？\n记录建议：记录研究领域、关键词、研究对象、研究类型和适用场景。\n\n2. 研究对象与范围\n核心关注点：论文研究的对象、边界与适用范围\n精读时要问：研究对象是什么？研究范围覆盖哪些时间、空间、群体、样本、文本、案例或系统？\n记录建议：写清楚“研究什么”和“不研究什么”。\n\n3. 研究问题\n核心关注点：论文要回答的核心问题\n精读时要问：作者提出了哪些研究问题、假设或目标？这些问题是否清楚、可检验、可讨论？\n记录建议：用 1 到 3 句话概括论文主问题和子问题。\n\n4. 研究背景与意义\n核心关注点：为什么值得研究\n精读时要问：作者如何说明问题的重要性？是理论价值、现实价值、政策价值、工程价值、教育价值，还是社会价值？\n记录建议：区分作者声称的意义和论文材料实际支撑的意义。\n\n5. 文献基础与研究空白\n核心关注点：已有研究与本文位置\n精读时要问：作者如何回顾已有研究？指出了什么不足、争议、缺口或未解决问题？\n记录建议：不要只列文献，要判断本文相对已有工作的具体增量。\n\n6. 理论框架或概念框架\n核心关注点：分析所依赖的理论、概念和分类体系\n精读时要问：论文使用了哪些理论、模型、概念、变量或分析框架？这些概念是否定义清楚？\n记录建议：把核心概念、变量关系和分析逻辑画成简图或表格。\n\n7. 研究设计与方法\n核心关注点：作者如何获得证据\n精读时要问：论文采用定量、定性、混合方法、实验、案例、文本分析、调查、访谈、建模，还是理论论证？\n记录建议：说明方法是否适合研究问题，是否存在明显方法局限。\n\n8. 材料、数据与样本\n核心关注点：证据来源是否可靠\n精读时要问：数据、文本、样本、案例或材料来自哪里？规模多大？选择标准是什么？是否有偏倚？\n记录建议：记录来源、筛选过程、样本特征、代表性和可获得性。\n\n9. 分析过程\n核心关注点：从材料到结论的推理链条\n精读时要问：作者如何编码、统计、比较、建模、解释或归纳？分析步骤是否透明？\n记录建议：把关键步骤按顺序整理，标出可能影响结果的主观判断或参数选择。\n\n10. 主要结果\n核心关注点：论文真正发现了什么\n精读时要问：核心发现、数据结果、案例发现、模式、机制或论证结论是什么？\n记录建议：区分“结果本身”和“作者对结果的解释”。\n\n11. 讨论与解释\n核心关注点：结果意味着什么\n精读时要问：作者如何解释结果？是否回应研究问题？是否与既有研究一致或冲突？\n记录建议：标出解释中由证据直接支持的部分，以及推测性较强的部分。\n\n12. 局限性与不确定性\n核心关注点：结论边界与风险\n精读时要问：作者承认了哪些局限？还有哪些未讨论的偏倚、替代解释或外推风险？\n记录建议：从数据、方法、样本、理论、场景和时间范围分别检查。\n\n13. 贡献与应用价值\n核心关注点：论文的实际增量\n精读时要问：论文对理论、方法、实践、政策、工程或教育有什么贡献？贡献是否被证据支撑？\n记录建议：不要直接照抄贡献声明，要判断贡献是否真实成立。\n\n14. 迁移、启发与后续研究\n核心关注点：这篇论文还能带来什么\n精读时要问：哪些思想、方法、框架或证据可以迁移到其他问题？后续研究可以如何改进？\n记录建议：记录可借鉴之处、不可迁移的限制和可进一步追问的问题。\n\n15. 个性化建议\n核心关注点：根据当前的文章解读结果，结合用户角色，给出进一步的个性化研究建议、为用户试设计新的idea、并规划详细的工作流。\n\n16. 前沿研究\n核心关注点：针对论文涉及到的研究内容，生成前沿研究分析。",
          "title": "其他领域相关论文默认章节安排",
          "source": "built-in",
          "createdAt": "built-in",
          "updatedAt": ""
      }
  ];

  function getBuiltInFocusEntries() {
    return normalizeFocusEntries(BUILTIN_FOCUS_ENTRIES.map((entry) => ({ ...entry })));
  }

  /* Shirley v31: separated, persistent focus logic for index/session and rules/default */
  const SESSION_FOCUS_KEY = 'shirley.sessionFocus.v1';
  const SESSION_FOCUS_FILES_KEY = 'shirley.sessionFocusFiles.v1';
  const DEFAULT_FOCUS_FILES_KEY = 'shirley.focusFiles.v1';
  const RULES_FOCUS_DRAFT_KEY = 'shirley.rulesFocusDraft.v1';
  const RULES_FOCUS_FILES_DRAFT_KEY = 'shirley.rulesFocusFilesDraft.v1';

  function readSessionJSON(key, fallback) {
    try {
      const raw = window.sessionStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (_) {
      return fallback;
    }
  }

  function writeSessionJSON(key, value) {
    try {
      window.sessionStorage.setItem(key, JSON.stringify(value));
    } catch (_) {
      /* sessionStorage may be unavailable or full */
    }
  }

  function removeSessionKey(key) {
    try {
      window.sessionStorage.removeItem(key);
    } catch (_) {
      /* ignore */
    }
  }

  function focusStorageEnabled() {
    return !!element('rulesForm');
  }

  function fileItemName(item) {
    return (item && item.file && item.file.name) || item.fileName || 'focus_file';
  }

  function fileItemSize(item) {
    return Number((item && item.file && item.file.size) || item.size || 0);
  }

  function fileItemType(item) {
    return (item && item.file && item.file.type) || item.type || 'unknown';
  }

  function fileItemLastModified(item) {
    return (item && item.file && item.file.lastModified) || item.lastModified || null;
  }

  function serializeFocusFiles(items) {
    return (items || []).map((item) => ({
      id: item.id || makeId('focus_file'),
      fileName: fileItemName(item),
      size: fileItemSize(item),
      type: fileItemType(item),
      lastModified: fileItemLastModified(item),
      storedPath: item.storedPath || '',
      dataUrl: item.dataUrl || '',
      textContent: item.textContent || '',
      createdAt: item.createdAt || new Date().toISOString()
    }));
  }

  function hydrateFocusFiles(items) {
    return (Array.isArray(items) ? items : []).map((item) => ({
      id: item.id || makeId('focus_file'),
      fileName: item.fileName || item.name || 'focus_file',
      size: Number(item.size || 0),
      type: item.type || 'unknown',
      lastModified: item.lastModified || null,
      storedPath: item.storedPath || '',
      dataUrl: item.dataUrl || '',
      textContent: item.textContent || '',
      createdAt: item.createdAt || new Date().toISOString()
    }));
  }

  function saveCurrentFocusFiles() {
    refreshStoredPaths('focusFiles');
    if (focusStorageEnabled()) {
      SkillUtils.writeJSON(DEFAULT_FOCUS_FILES_KEY, serializeFocusFiles(state.focusFiles));
    }
    const serialized = serializeFocusFiles(state.focusFiles);
    if (focusStorageEnabled()) {
      writeSessionJSON(RULES_FOCUS_FILES_DRAFT_KEY, serialized);
    } else {
      writeSessionJSON(SESSION_FOCUS_FILES_KEY, serialized);
    }
    return serialized;
  }

  function clearSessionFocusState() {
    removeSessionKey(SESSION_FOCUS_KEY);
    removeSessionKey(SESSION_FOCUS_FILES_KEY);
  }

  function clearDefaultFocusDraft() {
    removeSessionKey(RULES_FOCUS_DRAFT_KEY);
    removeSessionKey(RULES_FOCUS_FILES_DRAFT_KEY);
  }

  function initializeFocusEntries() {
    if (state.focusEntriesReady) return;
    state.focusEntriesReady = true;

    if (focusStorageEnabled()) {
      const draftEntries = readSessionJSON(RULES_FOCUS_DRAFT_KEY, null);
      if (Array.isArray(draftEntries)) {
        state.focusEntries = normalizeFocusEntries(draftEntries);
      } else {
        const entries = SkillUtils.readJSON(FOCUS_LIBRARY_KEY, null);
        if (Array.isArray(entries)) state.focusEntries = normalizeFocusEntries(entries);
        else {
          const oldItems = SkillUtils.readJSON(OLD_FOCUS_KEY, []);
          state.focusEntries = Array.isArray(oldItems) && oldItems.length
            ? normalizeFocusEntries(oldItems.map((text, index) => ({
                id: `focus_${Date.now()}_${index}`,
                text: String(text || '').trim(),
                title: '历史关注点',
                source: 'migrated',
                createdAt: new Date().toISOString()
              })))
            : [];
        }
      }

      const draftFiles = readSessionJSON(RULES_FOCUS_FILES_DRAFT_KEY, null);
      state.focusFiles = hydrateFocusFiles(Array.isArray(draftFiles) ? draftFiles : SkillUtils.readJSON(DEFAULT_FOCUS_FILES_KEY, []));
    } else {
      state.focusEntries = normalizeFocusEntries(readSessionJSON(SESSION_FOCUS_KEY, []));
      state.focusFiles = hydrateFocusFiles(readSessionJSON(SESSION_FOCUS_FILES_KEY, []));
    }

    refreshStoredPaths('focusFiles');
    if (focusStorageEnabled()) {
      SkillUtils.writeJSON(DEFAULT_FOCUS_FILES_KEY, serializeFocusFiles(state.focusFiles));
    }
  }

  function loadFocusEntries() {
    initializeFocusEntries();
    return normalizeFocusEntries(state.focusEntries || []);
  }

  function saveFocusEntries(entries) {
    const normalized = normalizeFocusEntries(entries);
    state.focusEntries = normalized;
    state.focusEntriesReady = true;
    if (focusStorageEnabled()) {
      writeSessionJSON(RULES_FOCUS_DRAFT_KEY, normalized);
    } else {
      writeSessionJSON(SESSION_FOCUS_KEY, normalized);
    }
    return normalized;
  }

  function commitFocusEntries() {
    const entries = normalizeFocusEntries(state.focusEntries || []);
    const files = serializeFocusFiles(state.focusFiles || []);
    state.focusEntries = entries;
    state.focusEntriesReady = true;
    SkillUtils.writeJSON(FOCUS_LIBRARY_KEY, entries);
    SkillUtils.writeJSON(DEFAULT_FOCUS_FILES_KEY, files);
    writeSessionJSON(RULES_FOCUS_DRAFT_KEY, entries);
    writeSessionJSON(RULES_FOCUS_FILES_DRAFT_KEY, files);
    return entries;
  }

  function defaultFocusEntries() {
    const savedFocusEntries = SkillUtils.readJSON(FOCUS_LIBRARY_KEY, null);
    return Array.isArray(savedFocusEntries) ? normalizeFocusEntries(savedFocusEntries) : getBuiltInFocusEntries();
  }

  function defaultFocusFiles() {
    const files = hydrateFocusFiles(SkillUtils.readJSON(DEFAULT_FOCUS_FILES_KEY, []));
    files.forEach((item) => {
      if (!item.storedPath) item.storedPath = `focus_uploads/${SkillUtils.sanitizeFileName(fileItemName(item))}`;
    });
    return files;
  }

  function hasCurrentFocus() {
    initializeFocusEntries();
    return !!((state.focusEntries && state.focusEntries.length) || (state.focusFiles && state.focusFiles.length));
  }

  function effectiveFocusEntries() {
    initializeFocusEntries();
    if (focusStorageEnabled()) return normalizeFocusEntries(state.focusEntries || []);
    return hasCurrentFocus() ? normalizeFocusEntries(state.focusEntries || []) : defaultFocusEntries();
  }

  function effectiveFocusFiles() {
    initializeFocusEntries();
    const files = focusStorageEnabled()
      ? (state.focusFiles || [])
      : (hasCurrentFocus() ? (state.focusFiles || []) : defaultFocusFiles());
    return hydrateFocusFiles(serializeFocusFiles(files));
  }

  function replaceFocusEntriesFromText(text) {
    const raw = normalizeFocusText(text);
    if (!raw) {
      saveFocusEntries([]);
      renderFocusList();
      return [];
    }
    const normalized = raw
      .replace(/\r\n/g, '\n')
      .replace(/^\s*\d+[\.\、]\s+/gm, '\n@@FOCUS@@')
      .split('\n@@FOCUS@@')
      .map((part) => part.trim())
      .filter(Boolean);
    const parts = normalized.length ? normalized : raw.split(/\n{2,}/).map((part) => part.trim()).filter(Boolean);
    const entries = saveFocusEntries(parts.map((part, index) => ({
      id: makeId('focus'),
      serial: index + 1,
      text: part,
      title: `关注点 ${index + 1}`,
      source: 'rules',
      createdAt: new Date().toISOString()
    })));
    renderFocusList();
    return entries;
  }

  function getFocusTextForRules() {
    return defaultFocusEntries().map((entry, index) => `${index + 1}. ${entry.text}`).join('\n\n');
  }

  function refreshStoredPaths(category) {
    if (category === 'focusFiles') {
      state.focusFiles.forEach((item) => {
        if (!item.id) item.id = makeId('focus_file');
        item.storedPath = `focus_uploads/${SkillUtils.sanitizeFileName(fileItemName(item))}`;
      });
      return;
    }
    state[category].forEach((item, index) => {
      item.storedPath = buildStoredName(item.file, category, index, item.scope || 'deep');
    });
  }

  function readFileAsDataUrl(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result || ''));
      reader.onerror = () => reject(reader.error || new Error('读取文件失败'));
      reader.readAsDataURL(file);
    });
  }

  async function addFocusFiles(fileList) {
    initializeFocusEntries();
    const errors = [];
    let textCount = 0;
    let fileCount = 0;
    const incoming = Array.from(fileList || []);

    for (const file of incoming) {
      const ext = SkillUtils.getExt(file.name);
      if (!ext || !FOCUS_FILE_EXT.has(ext)) {
        errors.push(`${file.name} 不是支持的关注点文件。`);
        continue;
      }

      const duplicated = state.focusFiles.some((item) => fileItemName(item) === file.name && fileItemSize(item) === file.size && fileItemLastModified(item) === file.lastModified);
      if (duplicated) {
        errors.push(`${file.name} 已经添加过。`);
        continue;
      }

      let textContent = '';
      if (isFocusTextFile(file)) {
        try {
          textContent = normalizeFocusText(await file.text());
          if (textContent) textCount += 1;
        } catch (_) {
          errors.push(`${file.name} 文本读取失败，仍会作为附件加入 focus_uploads。`);
        }
      }

      let dataUrl = '';
      try {
        dataUrl = await readFileAsDataUrl(file);
      } catch (_) {
        errors.push(`${file.name} 读取失败，未能加入 focus_uploads。`);
        continue;
      }

      const item = {
        id: makeId('focus_file'),
        file,
        fileName: file.name,
        size: file.size,
        type: file.type || 'unknown',
        lastModified: file.lastModified || null,
        dataUrl,
        textContent,
        storedPath: '',
        createdAt: new Date().toISOString()
      };
      state.focusFiles.push(item);
      focusSelection = { type: 'file', id: item.id };
      editingFocusId = '';
      fileCount += 1;
    }

    refreshStoredPaths('focusFiles');
    if (focusStorageEnabled()) {
      SkillUtils.writeJSON(DEFAULT_FOCUS_FILES_KEY, serializeFocusFiles(state.focusFiles));
    }
    saveCurrentFocusFiles();
    renderFocusList();
    updateFocusToolbarState();
    if (focusStorageEnabled()) {
      SkillUtils.writeJSON(DEFAULT_FOCUS_FILES_KEY, serializeFocusFiles(state.focusFiles));
    }
    return { errors, textCount, fileCount };
  }

  function removeFocusFile(index) {
    const removed = state.focusFiles[index];
    state.focusFiles.splice(index, 1);
    refreshStoredPaths('focusFiles');
    if (focusStorageEnabled()) {
      SkillUtils.writeJSON(DEFAULT_FOCUS_FILES_KEY, serializeFocusFiles(state.focusFiles));
    }
    saveCurrentFocusFiles();
    if (removed && focusSelection.type === 'file' && focusSelection.id === removed.id) {
      clearSelection();
      const box = element('focusText');
      if (box) box.value = '';
    }
    renderFocusList();
    updateFocusToolbarState();
    if (focusStorageEnabled()) {
      SkillUtils.writeJSON(DEFAULT_FOCUS_FILES_KEY, serializeFocusFiles(state.focusFiles));
    }
  }

  function persistFocusIfNeeded() {
    initializeFocusEntries();
    const box = element('focusText');
    const text = box ? normalizeFocusText(box.value) : '';
    if (!text) {
      if (!focusStorageEnabled()) {
        saveFocusEntries(state.focusEntries || []);
        saveCurrentFocusFiles();
      }
      return { ok: true, message: '无需保存空白重点关注。' };
    }
    if (focusSelection.type === 'file') {
      clearSelection();
      return appendFocusEntry(text, { source: 'input', title: '手动输入' });
    }
    if (editingFocusId) return updateFocusEntry(editingFocusId, text);
    return appendFocusEntry(text, { source: 'input', title: '手动输入' });
  }

  function compiledFocusText() {
    const entries = effectiveFocusEntries();
    const files = effectiveFocusFiles();
    state.effectiveFocusFiles = files;

    const lines = [];
    if (entries.length) {
      lines.push('文本关注点：');
      entries.forEach((entry, index) => lines.push(`${index + 1}. ${entry.text}`));
    }

    const textFiles = files.filter((item) => normalizeFocusText(item.textContent || ''));
    if (textFiles.length) {
      if (lines.length) lines.push('');
      lines.push('focus_uploads 文本内容：');
      textFiles.forEach((item, index) => {
        lines.push(`${index + 1}. ${fileItemName(item)}（见 ${item.storedPath}）`);
        lines.push(normalizeFocusText(item.textContent));
      });
    }

    if (files.length) {
      if (lines.length) lines.push('');
      lines.push('focus_uploads 地址：');
      files.forEach((item, index) => lines.push(`- 附件 ${index + 1}: ${fileItemName(item)}（见 ${item.storedPath}）`));
    }

    return lines.join('\n\n').trim();
  }

  function initFocusLibrary() {
    initializeFocusEntries();
    renderFocusList();
    const box = element('focusText');
    if (box) {
      box.value = '';
      box.addEventListener('input', () => {
        if (focusSelection.type === 'file' && normalizeFocusText(box.value)) {
          clearSelection();
          renderFocusList();
        }
        updateFocusToolbarState();
      });
    }
    updateFocusToolbarState();
  }


  function getCurrentFocusFiles() {
    initializeFocusEntries();
    return serializeFocusFiles(state.focusFiles || []);
  }

  function replaceFocusFilesFromImport(files) {
    state.focusFiles = hydrateFocusFiles(files || []);
    refreshStoredPaths('focusFiles');
    if (focusStorageEnabled()) {
      SkillUtils.writeJSON(DEFAULT_FOCUS_FILES_KEY, serializeFocusFiles(state.focusFiles));
    }
    saveCurrentFocusFiles();
    renderFocusList();
    updateFocusToolbarState();
    if (focusStorageEnabled()) {
      SkillUtils.writeJSON(DEFAULT_FOCUS_FILES_KEY, serializeFocusFiles(state.focusFiles));
    }
    return serializeFocusFiles(state.focusFiles);
  }


  /* Shirley v34: robust default-focus file persistence.
     Metadata is stored in local/session storage; file bodies are stored in IndexedDB. */
  const FOCUS_FILE_DB_NAME_V34 = 'shirley-focus-files-db-v1';
  const FOCUS_FILE_STORE_V34 = 'files';

  function focusFileMeta(item) {
    const name = fileItemName(item);
    const meta = {
      id: item.id || makeId('focus_file'),
      fileName: name,
      size: fileItemSize(item),
      type: fileItemType(item),
      lastModified: fileItemLastModified(item),
      storedPath: item.storedPath || flatStoredName(name, 'focus_01'),
      textContent: item.textContent || '',
      createdAt: item.createdAt || new Date().toISOString()
    };
    return meta;
  }

  function serializeFocusFiles(items) {
    return (items || []).map(focusFileMeta);
  }

  function hydrateFocusFiles(items) {
    return (Array.isArray(items) ? items : []).map((item) => {
      const fileName = item.fileName || item.name || (item.file && item.file.name) || 'focus_file';
      return {
        id: item.id || makeId('focus_file'),
        file: item.file || null,
        fileName,
        size: Number(item.size || (item.file && item.file.size) || 0),
        type: item.type || (item.file && item.file.type) || 'unknown',
        lastModified: item.lastModified || (item.file && item.file.lastModified) || null,
        storedPath: item.storedPath || flatStoredName(fileName, 'focus_01'),
        textContent: item.textContent || '',
        dataUrl: item.dataUrl || '',
        createdAt: item.createdAt || new Date().toISOString()
      };
    });
  }

  function openFocusFileDB() {
    return new Promise((resolve, reject) => {
      if (!('indexedDB' in window)) {
        reject(new Error('IndexedDB 不可用'));
        return;
      }
      const request = window.indexedDB.open(FOCUS_FILE_DB_NAME_V34, 1);
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains(FOCUS_FILE_STORE_V34)) {
          db.createObjectStore(FOCUS_FILE_STORE_V34, { keyPath: 'id' });
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error || new Error('IndexedDB 打开失败'));
    });
  }

  async function putFocusFileBlob(item) {
    if (!item || !item.id || !item.file) return;
    try {
      const db = await openFocusFileDB();
      await new Promise((resolve, reject) => {
        const tx = db.transaction(FOCUS_FILE_STORE_V34, 'readwrite');
        tx.objectStore(FOCUS_FILE_STORE_V34).put({
          id: item.id,
          blob: item.file,
          fileName: fileItemName(item),
          size: fileItemSize(item),
          type: fileItemType(item),
          lastModified: fileItemLastModified(item),
          storedPath: item.storedPath || `focus_uploads/${SkillUtils.sanitizeFileName(fileItemName(item))}`,
          textContent: item.textContent || '',
          savedAt: new Date().toISOString()
        });
        tx.oncomplete = resolve;
        tx.onerror = () => reject(tx.error || new Error('IndexedDB 写入失败'));
      });
      db.close();
    } catch (_) {
      /* IndexedDB may be blocked; metadata will still render, current File object may still package in this session. */
    }
  }

  async function deleteFocusFileBlob(id) {
    if (!id) return;
    try {
      const db = await openFocusFileDB();
      await new Promise((resolve, reject) => {
        const tx = db.transaction(FOCUS_FILE_STORE_V34, 'readwrite');
        tx.objectStore(FOCUS_FILE_STORE_V34).delete(id);
        tx.oncomplete = resolve;
        tx.onerror = () => reject(tx.error || new Error('IndexedDB 删除失败'));
      });
      db.close();
    } catch (_) {
      /* ignore */
    }
  }

  function focusStorageEnabled() {
    return !!element('rulesForm');
  }

  function saveCurrentFocusFiles() {
    refreshStoredPaths('focusFiles');
    const serialized = serializeFocusFiles(state.focusFiles || []);
    if (focusStorageEnabled()) {
      writeSessionJSON(RULES_FOCUS_FILES_DRAFT_KEY, serialized);
    } else {
      writeSessionJSON(SESSION_FOCUS_FILES_KEY, serialized);
    }
    return serialized;
  }

  function initializeFocusEntries() {
    if (state.focusEntriesReady) return;
    state.focusEntriesReady = true;

    if (focusStorageEnabled()) {
      const draftEntries = readSessionJSON(RULES_FOCUS_DRAFT_KEY, null);
      if (Array.isArray(draftEntries)) {
        state.focusEntries = normalizeFocusEntries(draftEntries);
      } else {
        const savedFocusEntries = SkillUtils.readJSON(FOCUS_LIBRARY_KEY, null);
    state.focusEntries = Array.isArray(savedFocusEntries) ? normalizeFocusEntries(savedFocusEntries) : getBuiltInFocusEntries();
      }

      const draftFiles = readSessionJSON(RULES_FOCUS_FILES_DRAFT_KEY, null);
      const savedFiles = SkillUtils.readJSON(DEFAULT_FOCUS_FILES_KEY, []);
      state.focusFiles = hydrateFocusFiles(Array.isArray(draftFiles) ? draftFiles : savedFiles);
    } else {
      state.focusEntries = normalizeFocusEntries(readSessionJSON(SESSION_FOCUS_KEY, []));
      state.focusFiles = hydrateFocusFiles(readSessionJSON(SESSION_FOCUS_FILES_KEY, []));
    }

    refreshStoredPaths('focusFiles');
  }

  function loadFocusEntries() {
    initializeFocusEntries();
    return normalizeFocusEntries(state.focusEntries || []);
  }

  function saveFocusEntries(entries) {
    const normalized = normalizeFocusEntries(entries);
    state.focusEntries = normalized;
    state.focusEntriesReady = true;
    if (focusStorageEnabled()) {
      writeSessionJSON(RULES_FOCUS_DRAFT_KEY, normalized);
    } else {
      writeSessionJSON(SESSION_FOCUS_KEY, normalized);
    }
    return normalized;
  }

  function commitFocusEntries() {
    initializeFocusEntries();
    const entries = normalizeFocusEntries(state.focusEntries || []);
    const files = serializeFocusFiles(state.focusFiles || []);
    state.focusEntries = entries;
    state.focusEntriesReady = true;

    SkillUtils.writeJSON(FOCUS_LIBRARY_KEY, entries);
    SkillUtils.writeJSON(DEFAULT_FOCUS_FILES_KEY, files);
    writeSessionJSON(RULES_FOCUS_DRAFT_KEY, entries);
    writeSessionJSON(RULES_FOCUS_FILES_DRAFT_KEY, files);
    return entries;
  }

  function defaultFocusEntries() {
    const savedFocusEntries = SkillUtils.readJSON(FOCUS_LIBRARY_KEY, null);
    return Array.isArray(savedFocusEntries) ? normalizeFocusEntries(savedFocusEntries) : getBuiltInFocusEntries();
  }

  function defaultFocusFiles() {
    const draftFiles = readSessionJSON(RULES_FOCUS_FILES_DRAFT_KEY, null);
    const files = Array.isArray(draftFiles) ? draftFiles : SkillUtils.readJSON(DEFAULT_FOCUS_FILES_KEY, []);
    return hydrateFocusFiles(files);
  }

  function hasCurrentFocus() {
    initializeFocusEntries();
    return !!((state.focusEntries && state.focusEntries.length) || (state.focusFiles && state.focusFiles.length));
  }

  function effectiveFocusEntries() {
    initializeFocusEntries();
    if (focusStorageEnabled()) return normalizeFocusEntries(state.focusEntries || []);
    return hasCurrentFocus() ? normalizeFocusEntries(state.focusEntries || []) : defaultFocusEntries();
  }

  function effectiveFocusFiles() {
    initializeFocusEntries();
    const files = focusStorageEnabled()
      ? (state.focusFiles || [])
      : (hasCurrentFocus() ? (state.focusFiles || []) : defaultFocusFiles());
    return hydrateFocusFiles(serializeFocusFiles(files));
  }

  async function addFocusFiles(fileList) {
    initializeFocusEntries();
    const errors = [];
    let textCount = 0;
    let fileCount = 0;
    const incoming = Array.from(fileList || []);

    for (const file of incoming) {
      const ext = SkillUtils.getExt(file.name);
      if (!ext || !FOCUS_FILE_EXT.has(ext)) {
        errors.push(`${file.name} 不是支持的关注点文件。`);
        continue;
      }

      const duplicated = state.focusFiles.some((item) => fileItemName(item) === file.name && fileItemSize(item) === file.size && fileItemLastModified(item) === file.lastModified);
      if (duplicated) {
        errors.push(`${file.name} 已经添加过。`);
        continue;
      }

      let textContent = '';
      if (isFocusTextFile(file)) {
        try {
          textContent = normalizeFocusText(await file.text());
          if (textContent) textCount += 1;
        } catch (_) {
          errors.push(`${file.name} 文本读取失败，仍会作为附件加入 focus_uploads。`);
        }
      }

      const item = {
        id: makeId('focus_file'),
        file,
        fileName: file.name,
        size: file.size,
        type: file.type || 'unknown',
        lastModified: file.lastModified || null,
        storedPath: '',
        textContent,
        createdAt: new Date().toISOString()
      };

      state.focusFiles.push(item);
      refreshStoredPaths('focusFiles');
      await putFocusFileBlob(item);

      focusSelection = { type: 'file', id: item.id };
      editingFocusId = '';
      fileCount += 1;
    }

    saveCurrentFocusFiles();
    renderFocusList();
    updateFocusToolbarState();
    return { errors, textCount, fileCount };
  }

  function removeFocusFile(index) {
    const removed = state.focusFiles[index];
    state.focusFiles.splice(index, 1);
    refreshStoredPaths('focusFiles');
    const serialized = saveCurrentFocusFiles();

    if (focusStorageEnabled()) {
      SkillUtils.writeJSON(DEFAULT_FOCUS_FILES_KEY, serialized);
      writeSessionJSON(RULES_FOCUS_FILES_DRAFT_KEY, serialized);
    }

    if (removed && removed.id) deleteFocusFileBlob(removed.id);

    if (removed && focusSelection.type === 'file' && focusSelection.id === removed.id) {
      clearSelection();
      const box = element('focusText');
      if (box) box.value = '';
    }
    renderFocusList();
    updateFocusToolbarState();
  }

  function replaceFocusFilesFromImport(files) {
    state.focusFiles = hydrateFocusFiles(files || []);
    refreshStoredPaths('focusFiles');
    saveCurrentFocusFiles();
    renderFocusList();
    updateFocusToolbarState();
    return serializeFocusFiles(state.focusFiles);
  }

  function getCurrentFocusFiles() {
    initializeFocusEntries();
    return serializeFocusFiles(state.focusFiles || []);
  }

  function clearDefaultFocusDraft() {
    removeSessionKey(RULES_FOCUS_DRAFT_KEY);
    removeSessionKey(RULES_FOCUS_FILES_DRAFT_KEY);
    SkillUtils.writeJSON(DEFAULT_FOCUS_FILES_KEY, []);
  }


  /* Shirley v35: rules-page unsaved-change guard.
     In rules page, focus changes stay in memory until "保存配置".
     Leaving with unsaved changes can discard them and restore the last saved state. */
  function focusStorageEnabled() {
    return !!element('rulesForm');
  }

  function saveCurrentFocusFiles() {
    refreshStoredPaths('focusFiles');
    const serialized = serializeFocusFiles(state.focusFiles || []);
    if (!focusStorageEnabled()) writeSessionJSON(SESSION_FOCUS_FILES_KEY, serialized);
    return serialized;
  }

  function initializeFocusEntries() {
    if (state.focusEntriesReady) return;
    state.focusEntriesReady = true;

    if (focusStorageEnabled()) {
      const savedFocusEntries = SkillUtils.readJSON(FOCUS_LIBRARY_KEY, null);
      state.focusEntries = Array.isArray(savedFocusEntries) ? normalizeFocusEntries(savedFocusEntries) : getBuiltInFocusEntries();
      state.focusFiles = hydrateFocusFiles(SkillUtils.readJSON(DEFAULT_FOCUS_FILES_KEY, []));
    } else {
      state.focusEntries = normalizeFocusEntries(readSessionJSON(SESSION_FOCUS_KEY, []));
      state.focusFiles = hydrateFocusFiles(readSessionJSON(SESSION_FOCUS_FILES_KEY, []));
    }

    refreshStoredPaths('focusFiles');
  }

  function loadFocusEntries() {
    initializeFocusEntries();
    return normalizeFocusEntries(state.focusEntries || []);
  }

  function saveFocusEntries(entries) {
    const normalized = normalizeFocusEntries(entries);
    state.focusEntries = normalized;
    state.focusEntriesReady = true;
    if (!focusStorageEnabled()) writeSessionJSON(SESSION_FOCUS_KEY, normalized);
    return normalized;
  }

  function commitFocusEntries() {
    initializeFocusEntries();
    const previousFiles = hydrateFocusFiles(SkillUtils.readJSON(DEFAULT_FOCUS_FILES_KEY, []));
    const previousIds = new Set(previousFiles.map((item) => item.id).filter(Boolean));
    const currentFiles = serializeFocusFiles(state.focusFiles || []);
    const currentIds = new Set(currentFiles.map((item) => item.id).filter(Boolean));
    previousIds.forEach((id) => {
      if (!currentIds.has(id)) deleteFocusFileBlob(id);
    });

    const entries = normalizeFocusEntries(state.focusEntries || []);
    state.focusEntries = entries;
    state.focusEntriesReady = true;

    SkillUtils.writeJSON(FOCUS_LIBRARY_KEY, entries);
    SkillUtils.writeJSON(DEFAULT_FOCUS_FILES_KEY, currentFiles);
    clearDefaultFocusDraft();
    return entries;
  }

  function defaultFocusEntries() {
    const savedFocusEntries = SkillUtils.readJSON(FOCUS_LIBRARY_KEY, null);
    return Array.isArray(savedFocusEntries) ? normalizeFocusEntries(savedFocusEntries) : getBuiltInFocusEntries();
  }

  function defaultFocusFiles() {
    return hydrateFocusFiles(SkillUtils.readJSON(DEFAULT_FOCUS_FILES_KEY, []));
  }

  function hasCurrentFocus() {
    initializeFocusEntries();
    return !!((state.focusEntries && state.focusEntries.length) || (state.focusFiles && state.focusFiles.length));
  }

  function effectiveFocusEntries() {
    initializeFocusEntries();
    if (focusStorageEnabled()) return normalizeFocusEntries(state.focusEntries || []);
    return hasCurrentFocus() ? normalizeFocusEntries(state.focusEntries || []) : defaultFocusEntries();
  }

  function effectiveFocusFiles() {
    initializeFocusEntries();
    const files = focusStorageEnabled()
      ? (state.focusFiles || [])
      : (hasCurrentFocus() ? (state.focusFiles || []) : defaultFocusFiles());
    return hydrateFocusFiles(serializeFocusFiles(files));
  }

  async function addFocusFiles(fileList) {
    initializeFocusEntries();
    const errors = [];
    let textCount = 0;
    let fileCount = 0;
    const incoming = Array.from(fileList || []);

    for (const file of incoming) {
      const ext = SkillUtils.getExt(file.name);
      if (!ext || !FOCUS_FILE_EXT.has(ext)) {
        errors.push(`${file.name} 不是支持的关注点文件。`);
        continue;
      }

      const duplicated = state.focusFiles.some((item) => fileItemName(item) === file.name && fileItemSize(item) === file.size && fileItemLastModified(item) === file.lastModified);
      if (duplicated) {
        errors.push(`${file.name} 已经添加过。`);
        continue;
      }

      let textContent = '';
      if (isFocusTextFile(file)) {
        try {
          textContent = normalizeFocusText(await file.text());
          if (textContent) textCount += 1;
        } catch (_) {
          errors.push(`${file.name} 文本读取失败，仍会作为附件加入 focus_uploads。`);
        }
      }

      const item = {
        id: makeId('focus_file'),
        file,
        fileName: file.name,
        size: file.size,
        type: file.type || 'unknown',
        lastModified: file.lastModified || null,
        storedPath: '',
        textContent,
        createdAt: new Date().toISOString()
      };

      state.focusFiles.push(item);
      refreshStoredPaths('focusFiles');
      await putFocusFileBlob(item);

      focusSelection = { type: 'file', id: item.id };
      editingFocusId = '';
      fileCount += 1;
    }

    saveCurrentFocusFiles();
    renderFocusList();
    updateFocusToolbarState();
    return { errors, textCount, fileCount };
  }

  function removeFocusFile(index) {
    const removed = state.focusFiles[index];
    state.focusFiles.splice(index, 1);
    refreshStoredPaths('focusFiles');
    saveCurrentFocusFiles();

    if (!focusStorageEnabled() && removed && removed.id) deleteFocusFileBlob(removed.id);

    if (removed && focusSelection.type === 'file' && focusSelection.id === removed.id) {
      clearSelection();
      const box = element('focusText');
      if (box) box.value = '';
    }
    renderFocusList();
    updateFocusToolbarState();
  }

  function replaceFocusFilesFromImport(files) {
    state.focusFiles = hydrateFocusFiles(files || []);
    refreshStoredPaths('focusFiles');
    saveCurrentFocusFiles();
    renderFocusList();
    updateFocusToolbarState();
    return serializeFocusFiles(state.focusFiles);
  }

  function clearDefaultFocusDraft() {
    removeSessionKey(RULES_FOCUS_DRAFT_KEY);
    removeSessionKey(RULES_FOCUS_FILES_DRAFT_KEY);
  }

  function focusStateSnapshot() {
    initializeFocusEntries();
    return JSON.stringify({
      entries: normalizeFocusEntries(state.focusEntries || []).map((entry, index) => ({
        serial: index + 1,
        text: entry.text || '',
        title: entry.title || '',
        source: entry.source || ''
      })),
      files: serializeFocusFiles(state.focusFiles || []).map((item) => ({
        id: item.id || '',
        fileName: item.fileName || '',
        size: item.size || 0,
        type: item.type || '',
        lastModified: item.lastModified || null,
        storedPath: item.storedPath || '',
        textContent: item.textContent || ''
      }))
    });
  }

  function restoreSavedFocusState() {
    initializeFocusEntries();
    const savedFiles = hydrateFocusFiles(SkillUtils.readJSON(DEFAULT_FOCUS_FILES_KEY, []));
    const savedIds = new Set(savedFiles.map((item) => item.id).filter(Boolean));
    (state.focusFiles || []).forEach((item) => {
      if (item && item.id && !savedIds.has(item.id)) deleteFocusFileBlob(item.id);
    });

    const savedFocusEntries = SkillUtils.readJSON(FOCUS_LIBRARY_KEY, null);
    state.focusEntries = Array.isArray(savedFocusEntries) ? normalizeFocusEntries(savedFocusEntries) : getBuiltInFocusEntries();
    state.focusFiles = savedFiles;
    state.focusEntriesReady = true;
    clearDefaultFocusDraft();
    clearSelection();

    const box = element('focusText');
    if (box) box.value = '';
    refreshStoredPaths('focusFiles');
    renderFocusList();
    updateFocusToolbarState();
  }

  function getCurrentFocusFiles() {
    initializeFocusEntries();
    return serializeFocusFiles(state.focusFiles || []);
  }


  /* Shirley v37: keep index uploaded materials when navigating to rules and back.
     Metadata is kept in sessionStorage; file bodies are kept in IndexedDB. */
  const MATERIALS_SESSION_KEY_V37 = 'shirley.sessionMaterials.v2';
  const MATERIAL_FILE_DB_NAME_V37 = 'shirley-material-files-db-v1';
  const MATERIAL_FILE_STORE_V37 = 'files';

  function materialFileName(item) {
    return (item && item.file && item.file.name) || item.fileName || 'material_file';
  }

  function materialFileSize(item) {
    return Number((item && item.file && item.file.size) || item.size || 0);
  }

  function materialFileType(item) {
    return (item && item.file && item.file.type) || item.type || 'unknown';
  }

  function materialFileLastModified(item) {
    return (item && item.file && item.file.lastModified) || item.lastModified || null;
  }

  function materialMeta(item, category) {
    const name = materialFileName(item);
    return {
      id: item.id || makeId(`${category || 'material'}_file`),
      category: category || item.category || '',
      scope: item.scope || 'deep',
      fileName: name,
      size: materialFileSize(item),
      type: materialFileType(item),
      lastModified: materialFileLastModified(item),
      storedPath: item.storedPath || '',
      createdAt: item.createdAt || new Date().toISOString()
    };
  }

  function serializeMaterialItems(items, category) {
    return (items || []).map((item) => materialMeta(item, category));
  }

  function hydrateMaterialItems(items, category) {
    return (Array.isArray(items) ? items : []).map((item) => ({
      id: item.id || makeId(`${category || item.category || 'material'}_file`),
      category: category || item.category || '',
      scope: item.scope || 'deep',
      file: item.file || null,
      fileName: item.fileName || item.name || (item.file && item.file.name) || 'material_file',
      size: Number(item.size || (item.file && item.file.size) || 0),
      type: item.type || (item.file && item.file.type) || 'unknown',
      lastModified: item.lastModified || (item.file && item.file.lastModified) || null,
      storedPath: item.storedPath || '',
      createdAt: item.createdAt || new Date().toISOString()
    }));
  }

  function materialSessionSnapshot() {
    return {
      docs: serializeMaterialItems(state.docs || [], 'docs'),
      images: serializeMaterialItems(state.images || [], 'images'),
      data: serializeMaterialItems(state.data || [], 'data'),
      links: Array.isArray(state.links) ? state.links : []
    };
  }

  function saveMaterialSession() {
    try {
      window.sessionStorage.setItem(MATERIALS_SESSION_KEY_V37, JSON.stringify(materialSessionSnapshot()));
    } catch (_) {
      /* sessionStorage may be unavailable or full */
    }
  }

  function loadMaterialSession() {
    if (state.materialsReady) return;
    state.materialsReady = true;
    let saved = null;
    try {
      const raw = window.sessionStorage.getItem(MATERIALS_SESSION_KEY_V37);
      saved = raw ? JSON.parse(raw) : null;
    } catch (_) {
      saved = null;
    }
    if (!saved || typeof saved !== 'object') return;

    state.docs = hydrateMaterialItems(saved.docs || [], 'docs');
    state.images = hydrateMaterialItems(saved.images || [], 'images');
    state.data = hydrateMaterialItems(saved.data || [], 'data');
    state.links = Array.isArray(saved.links) ? saved.links : [];
    ['docs', 'images', 'data'].forEach((category) => refreshStoredPaths(category));
  }

  function openMaterialFileDB() {
    return new Promise((resolve, reject) => {
      if (!('indexedDB' in window)) {
        reject(new Error('IndexedDB 不可用'));
        return;
      }
      const request = window.indexedDB.open(MATERIAL_FILE_DB_NAME_V37, 1);
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains(MATERIAL_FILE_STORE_V37)) {
          db.createObjectStore(MATERIAL_FILE_STORE_V37, { keyPath: 'id' });
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error || new Error('IndexedDB 打开失败'));
    });
  }

  async function putMaterialFileBlob(item, category) {
    if (!item || !item.id || !item.file) return;
    try {
      const db = await openMaterialFileDB();
      await new Promise((resolve, reject) => {
        const tx = db.transaction(MATERIAL_FILE_STORE_V37, 'readwrite');
        tx.objectStore(MATERIAL_FILE_STORE_V37).put({
          id: item.id,
          category,
          scope: item.scope || 'deep',
          blob: item.file,
          fileName: materialFileName(item),
          size: materialFileSize(item),
          type: materialFileType(item),
          lastModified: materialFileLastModified(item),
          storedPath: item.storedPath || '',
          savedAt: new Date().toISOString()
        });
        tx.oncomplete = resolve;
        tx.onerror = () => reject(tx.error || new Error('IndexedDB 写入失败'));
      });
      db.close();
    } catch (_) {
      /* Current File object can still be used in this session. */
    }
  }

  async function deleteMaterialFileBlob(id) {
    if (!id) return;
    try {
      const db = await openMaterialFileDB();
      await new Promise((resolve, reject) => {
        const tx = db.transaction(MATERIAL_FILE_STORE_V37, 'readwrite');
        tx.objectStore(MATERIAL_FILE_STORE_V37).delete(id);
        tx.oncomplete = resolve;
        tx.onerror = () => reject(tx.error || new Error('IndexedDB 删除失败'));
      });
      db.close();
    } catch (_) {
      /* ignore */
    }
  }

  function splitFileNameForSuffix(name) {
    const safe = SkillUtils.sanitizeFileName(String(name || 'file'));
    const dot = safe.lastIndexOf('.');
    if (dot > 0 && dot < safe.length - 1) {
      return { base: safe.slice(0, dot), ext: safe.slice(dot) };
    }
    return { base: safe, ext: '' };
  }

  function flatSuffix(category, scope, index) {
    const scopeCode = scope === 'external' ? 'e' : 'd';
    const categoryCode = {
      docs: 'doc',
      images: 'img',
      data: 'data',
      focusFiles: 'focus'
    }[category] || 'file';
    const serial = String((index || 0) + 1).padStart(2, '0');
    return category === 'focusFiles'
      ? `${categoryCode}_${serial}`
      : `${scopeCode}_${categoryCode}_${serial}`;
  }

  function flatStoredName(rawName, suffix) {
    const parts = splitFileNameForSuffix(rawName);
    return `${parts.base}__${suffix}${parts.ext}`;
  }

  function buildStoredName(fileOrItem, category, index, scope) {
    const raw = (fileOrItem && fileOrItem.name) || materialFileName(fileOrItem);
    return flatStoredName(raw, flatSuffix(category, scope || 'deep', index));
  }

  function refreshStoredPaths(category) {
    if (category === 'focusFiles') {
      state.focusFiles.forEach((item, index) => {
        if (!item.id) item.id = makeId('focus_file');
        item.storedPath = flatStoredName(fileItemName(item), flatSuffix('focusFiles', 'deep', index));
      });
      return;
    }
    state[category].forEach((item, index) => {
      if (!item.id) item.id = makeId(`${category}_file`);
      item.category = category;
      item.storedPath = buildStoredName(item, category, index, item.scope || 'deep');
    });
  }

  function updateUploadStats() {
    const imageCount = element('imageCount');
    const docCount = element('docCount');
    const dataCount = element('dataCount');
    const linkCount = element('linkCount');
    const totalSize = element('totalSize');
    const totalBytes = ['images', 'docs', 'data'].reduce(
      (sum, key) => sum + state[key].reduce((s, item) => s + materialFileSize(item), 0),
      0
    );
    if (imageCount) imageCount.textContent = String(state.images.length);
    if (docCount) docCount.textContent = String(state.docs.length);
    if (dataCount) dataCount.textContent = String(state.data.length);
    if (linkCount) linkCount.textContent = String(state.links.length);
    if (totalSize) {
      const readableSize = SkillUtils.formatBytes(totalBytes);
      totalSize.textContent = readableSize;
      totalSize.title = readableSize;
      totalSize.setAttribute('aria-label', `总大小：${readableSize}`);
    }
  }

  function renderFileList(category) {
    const meta = CATEGORY_META[category];
    const list = element(meta.listId);
    if (!list) return;
    loadMaterialSession();

    const scope = getScope(category);
    const scopedItems = state[category]
      .map((item, index) => ({ item, index }))
      .filter((entry) => (entry.item.scope || 'deep') === scope);

    list.innerHTML = '';
    if (!scopedItems.length) {
      const empty = document.createElement('li');
      empty.className = 'file-empty';
      empty.textContent = `尚未选择${scopedTitle(category, scope)}`;
      list.appendChild(empty);
      updateUploadStats();
      return;
    }

    scopedItems.forEach(({ item, index }) => {
      const li = document.createElement('li');
      li.className = 'file-item';

      const detail = document.createElement('div');
      const name = document.createElement('div');
      const metaLine = document.createElement('div');
      name.className = 'file-name';
      metaLine.className = 'file-meta';

      const fileName = materialFileName(item);
      name.title = fileName;
      name.textContent = fileName;
      metaLine.textContent = `${SkillUtils.formatBytes(materialFileSize(item))} · ${SkillUtils.getExt(fileName).toUpperCase() || '未知类型'}`;
      detail.appendChild(name);
      detail.appendChild(metaLine);

      const button = document.createElement('button');
      button.className = 'file-remove';
      button.type = 'button';
      button.setAttribute('aria-label', `移除 ${fileName}`);
      button.textContent = '×';
      button.addEventListener('click', () => removeFile(category, index));

      li.appendChild(detail);
      li.appendChild(button);
      list.appendChild(li);
    });
    updateUploadStats();
  }

  async function addFiles(fileList, category) {
    loadMaterialSession();
    const errors = [];
    const incoming = Array.from(fileList || []);
    const scope = getScope(category);

    for (const file of incoming) {
      const error = validateFileForCategory(file, category);
      if (error) {
        errors.push(error);
        continue;
      }

      const duplicated = state[category].some((item) =>
        materialFileName(item) === file.name &&
        materialFileSize(item) === file.size &&
        materialFileLastModified(item) === file.lastModified &&
        item.scope === scope
      );
      if (duplicated) {
        errors.push(`${file.name} 已经添加过。`);
        continue;
      }

      const item = {
        id: makeId(`${category}_file`),
        category,
        file,
        fileName: file.name,
        size: file.size,
        type: file.type || 'unknown',
        lastModified: file.lastModified || null,
        scope,
        storedPath: '',
        createdAt: new Date().toISOString()
      };
      state[category].push(item);
      refreshStoredPaths(category);
      await putMaterialFileBlob(item, category);
    }

    refreshStoredPaths(category);
    saveMaterialSession();
    renderFileList(category);
    updateUploadStats();
    return errors;
  }

  function removeFile(category, index) {
    loadMaterialSession();
    const removed = state[category][index];
    state[category].splice(index, 1);
    refreshStoredPaths(category);
    if (removed && removed.id) deleteMaterialFileBlob(removed.id);
    saveMaterialSession();
    renderFileList(category);
    updateUploadStats();
  }

  function addLinks(rawText) {
    loadMaterialSession();
    const scope = getScope('links');
    const lines = String(rawText || '').split(/\n+/).map((line) => line.trim()).filter(Boolean);
    if (!lines.length) return { ok: false, added: 0, errors: ['请先输入链接材料。'] };
    const errors = [];
    let added = 0;
    lines.forEach((line) => {
      if (!isProbablyLink(line)) {
        errors.push(`${line} 看起来不像有效链接 / DOI / arXiv 编号。`);
        return;
      }
      const duplicated = state.links.some((item) => item.value === line && item.scope === scope);
      if (duplicated) {
        errors.push(`${line} 已经添加过。`);
        return;
      }
      state.links.push({ id: makeId('link'), scope, value: line, title: scopedTitle('links', scope), createdAt: new Date().toISOString() });
      added += 1;
    });
    saveMaterialSession();
    renderLinkList();
    updateUploadStats();
    return { ok: added > 0 && !errors.length, added, errors };
  }

  function removeLink(index) {
    loadMaterialSession();
    state.links.splice(index, 1);
    saveMaterialSession();
    renderLinkList();
    updateUploadStats();
  }

  function initMaterialControls() {
    loadMaterialSession();
    renderFileList('docs');
    renderFileList('images');
    renderFileList('data');
    renderLinkList();
    updateUploadStats();
    updateDocRequiredMarker();
  }

  function resetAll() {
    element('skillForm').reset();

    ['docs', 'images', 'data'].forEach((category) => {
      state[category].forEach((item) => {
        if (item && item.id) deleteMaterialFileBlob(item.id);
      });
    });

    state.docs = [];
    state.images = [];
    state.data = [];
    state.links = [];
    state.focusFiles = [];
    state.focusEntries = [];
    state.effectiveFocusFiles = [];
    state.materialsReady = true;
    state.focusEntriesReady = true;
    if (!focusStorageEnabled()) {
      clearSessionFocusState();
      try { window.sessionStorage.removeItem(MATERIALS_SESSION_KEY_V37); } catch (_) {}
    }
    clearSelection();
    const box = element('focusText');
    const linkInput = element('linkInput');
    if (box) box.value = '';
    if (linkInput) linkInput.value = '';
    renderFileList('docs');
    renderFileList('images');
    renderFileList('data');
    renderLinkList();
    renderFocusList();
    refreshRuleStatus();
    updateFocusToolbarState();
    updateUploadStats();
  }


  function restoreBuiltInFocusDefaults() {
    state.focusEntries = getBuiltInFocusEntries();
    state.focusEntriesReady = true;
    SkillUtils.storageRemove(FOCUS_LIBRARY_KEY);
    clearSelection();
    const box = element('focusText');
    if (box) box.value = '';
    renderFocusList();
    updateFocusToolbarState();
    return state.focusEntries;
  }

  window.SkillForm = {
    state,
    CATEGORY_META,
    DEFAULT_RULES,
    RULES_KEY,
    FOCUS_LIBRARY_KEY,
    addFiles,
    addLinks,
    addFocusFiles,
    readForm,
    validateRequired,
    resetAll,
    initFocusLibrary,
    initRuleMode,
    initMaterialControls,
    initMaterialSelectors,
    addFocusItem,
    updateFocusItem,
    clearFocusInput,
    clearDefaultFocusDraft,
    deleteFocusEntry,
    updateUploadStats,
    renderFileList,
    renderLinkList,
    renderFocusList,
    persistFocusIfNeeded,
    commitFocusEntries,
    focusStorageEnabled,
    focusStateSnapshot,
    restoreSavedFocusState,
    restoreBuiltInFocusDefaults,
    getCurrentFocusFiles,
    replaceFocusFilesFromImport,
    getCustomRules,
    getDefaultRules,
    getBuiltInRules,
    getFocusItems: loadFocusEntries,
    getFocusTextForRules,
    replaceFocusEntriesFromText,
    scopeLabel
  };
})();
