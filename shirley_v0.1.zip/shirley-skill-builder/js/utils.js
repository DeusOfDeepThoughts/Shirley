(function () {
  'use strict';

  const memoryStore = {};

  function storageGet(key, fallback = null) {
    try {
      const value = window.localStorage.getItem(key);
      return value === null ? fallback : value;
    } catch (_) {
      return Object.prototype.hasOwnProperty.call(memoryStore, key) ? memoryStore[key] : fallback;
    }
  }

  function storageSet(key, value) {
    try {
      window.localStorage.setItem(key, value);
    } catch (_) {
      memoryStore[key] = value;
    }
  }

  function storageRemove(key) {
    try {
      window.localStorage.removeItem(key);
    } catch (_) {
      delete memoryStore[key];
    }
  }



  function showModal(options) {
    const settings = Object.assign({
      title: '提示',
      message: '',
      type: 'info',
      confirmText: '确定',
      cancelText: '',
      showCancel: false
    }, options || {});

    return new Promise((resolve) => {
      const previous = document.querySelector('.modal-backdrop');
      if (previous) previous.remove();

      const backdrop = document.createElement('div');
      backdrop.className = 'modal-backdrop';
      backdrop.setAttribute('role', 'dialog');
      backdrop.setAttribute('aria-modal', 'true');

      const card = document.createElement('div');
      card.className = `modal-card modal-card--${settings.type}`;

      const top = document.createElement('div');
      top.className = 'modal-card__top';

      const icon = document.createElement('div');
      icon.className = 'modal-icon';
      icon.setAttribute('aria-hidden', 'true');
      icon.textContent = settings.type === 'ok' ? '✓' : settings.type === 'error' ? '!' : settings.type === 'confirm' ? '?' : 'i';

      const title = document.createElement('h3');
      title.className = 'modal-title';
      title.textContent = settings.title;

      const body = document.createElement('div');
      body.className = 'modal-body';
      body.textContent = settings.message;

      const actions = document.createElement('div');
      actions.className = 'modal-actions';

      function close(value) {
        backdrop.remove();
        resolve(value);
      }

      if (settings.showCancel) {
        const cancel = document.createElement('button');
        cancel.type = 'button';
        cancel.className = 'btn btn--ghost';
        cancel.textContent = settings.cancelText || '取消';
        cancel.addEventListener('click', () => close(false));
        actions.appendChild(cancel);
      }

      const confirm = document.createElement('button');
      confirm.type = 'button';
      confirm.className = settings.type === 'error' ? 'btn btn--danger' : 'btn btn--primary';
      confirm.textContent = settings.confirmText || '确定';
      confirm.addEventListener('click', () => close(true));
      actions.appendChild(confirm);

      top.appendChild(icon);
      top.appendChild(title);
      card.appendChild(top);
      card.appendChild(body);
      card.appendChild(actions);
      backdrop.appendChild(card);
      document.body.appendChild(backdrop);

      confirm.focus({ preventScroll: true });
      backdrop.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') close(false);
      });
    });
  }

  function showAlert(message, type = 'info', title = '') {
    const resolvedTitle = title || (type === 'ok' ? '已完成' : type === 'error' ? '需要处理' : '提示');
    return showModal({ title: resolvedTitle, message, type, confirmText: '知道了' });
  }

  function showConfirm(message, title = '请确认') {
    return showModal({ title, message, type: 'confirm', confirmText: '确定', cancelText: '取消', showCancel: true });
  }

  let patrickAudioPlayer = null;

  function speakPatrickLine(text) {
    try {
      const src = String(text || '').includes('好了好了')
        ? 'assets/audio/patrick_love_back.mp3'
        : 'assets/audio/patrick_love_you.mp3';

      if (patrickAudioPlayer) {
        patrickAudioPlayer.pause();
        patrickAudioPlayer.currentTime = 0;
      }

      patrickAudioPlayer = new Audio(src);
      patrickAudioPlayer.volume = 1;
      const playing = patrickAudioPlayer.play();
      if (playing && typeof playing.catch === 'function') {
        playing.catch(() => {});
      }
    } catch (_) {
      /* Local audio playback may be blocked by browser policy until user interaction. */
    }
  }

  function showPatrickBubble(target, text) {
    const old = document.querySelector('.patrick-bubble');
    if (old) old.remove();

    const bubble = document.createElement('div');
    bubble.className = 'patrick-bubble';
    bubble.textContent = text;
    document.body.appendChild(bubble);

    const rect = target.getBoundingClientRect();
    bubble.style.left = `${Math.min(window.innerWidth - 28, Math.max(14, rect.left + rect.width / 2))}px`;
    bubble.style.top = `${Math.max(14, rect.bottom + 10)}px`;

    setTimeout(() => bubble.classList.add('is-show'), 20);
    setTimeout(() => {
      bubble.classList.remove('is-show');
      setTimeout(() => bubble.remove(), 220);
    }, 1800);
  }

  function bindPatrickLove() {
    const nodes = document.querySelectorAll('.patrick-note--button');
    nodes.forEach((node) => {
      if (node.dataset.patrickBound === '1') return;
      node.dataset.patrickBound = '1';
      node.addEventListener('click', () => {
        const current = Number(node.dataset.patrickClicks || '0') + 1;
        node.dataset.patrickClicks = String(current);
        const line = current >= 3
          ? '好了好了，派大星知道你也超爱派大星'
          : '没错，派大星真的超爱你';

        node.classList.remove('is-booped');
        void node.offsetWidth;
        node.classList.add('is-booped');
        setTimeout(() => node.classList.remove('is-booped'), 260);

        showPatrickBubble(node, line);
        speakPatrickLine(line);
      });
    });
  }


  window.SkillUtils = {
    pad2(value) { return String(value).padStart(2, '0'); },

    timestampForName(date = new Date()) {
      const y = date.getFullYear();
      const m = this.pad2(date.getMonth() + 1);
      const d = this.pad2(date.getDate());
      const h = this.pad2(date.getHours());
      const min = this.pad2(date.getMinutes());
      const s = this.pad2(date.getSeconds());
      return `${y}${m}${d}_${h}${min}${s}`;
    },

    safeText(value, fallback = '未填写') {
      const text = String(value || '').trim();
      return text.length ? text : fallback;
    },

    escapeMd(value) { return String(value || '').replace(/\r\n/g, '\n').trim(); },

    getExt(fileName) {
      const name = String(fileName || '').toLowerCase();
      const index = name.lastIndexOf('.');
      return index >= 0 ? name.slice(index + 1) : '';
    },

    sanitizeFileName(fileName) {
      const cleaned = String(fileName || 'file')
        .replace(/[\\/:*?"<>|]/g, '_')
        .replace(/\s+/g, '_')
        .replace(/_+/g, '_')
        .replace(/^_+|_+$/g, '');
      return cleaned || 'file';
    },

    formatBytes(bytes) {
      if (!Number.isFinite(bytes)) return '未知大小';
      const units = ['B', 'KB', 'MB', 'GB'];
      let value = bytes;
      let unitIndex = 0;
      while (value >= 1024 && unitIndex < units.length - 1) {
        value /= 1024;
        unitIndex += 1;
      }
      return `${value.toFixed(value >= 10 || unitIndex === 0 ? 0 : 1)} ${units[unitIndex]}`;
    },

    textToBytes(text) { return new TextEncoder().encode(text); },

    async fileToBytes(file) {
      const buffer = await file.arrayBuffer();
      return new Uint8Array(buffer);
    },

    showModal,
    showAlert,
    showConfirm,
    bindPatrickLove,

    storageGet,
    storageSet,
    storageRemove,

    readJSON(key, fallback) {
      try {
        const raw = storageGet(key, '');
        return raw ? JSON.parse(raw) : fallback;
      } catch (_) {
        return fallback;
      }
    },

    writeJSON(key, value) {
      storageSet(key, JSON.stringify(value));
    }
  };
})();
